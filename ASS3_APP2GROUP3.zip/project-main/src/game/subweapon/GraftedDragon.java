package game.subweapon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.enums.Status;
import game.interfaces.Sellable;
import game.subweapon.skills.AOEAttack;

/**
 * A class representing the Grafted Dragon weapon. This weapon is obtained from
 * Godrick's remembrance. Deals 89 damage with 90% accuracy, and has an AOE attack.
 *
 * Created by:
 * @author Argya
 */
public class GraftedDragon extends WeaponItem implements Sellable {
    /**
     * Constructor.
     *
     *
     */
    public GraftedDragon() {
        super("Grafted Dragon", 'N', 89, "smacks", 90);
        this.addCapability(Status.IS_WEAPON_ITEM);
        this.addCapability(Status.IS_SELLABLE);
    }

    /**
     * Returns an AOE Attack
     * @param target target actor
     * @param direction direction the skill is being used in (not used in this method)
     * @return
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new AOEAttack(this, "smacks");
    }

    /**
     * Returns the selling rune value of the weapon
     * @return the selling rune value
     */
    @Override
    public int sellRuneValue() {
        return 200;
    }


    /**
     * Returns true if the item is a weapon item
     * @param isWeaponItem an ENUM Status
     * @return true if it has capability IS_WEAPON_ITEM
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return false;
    }
}
