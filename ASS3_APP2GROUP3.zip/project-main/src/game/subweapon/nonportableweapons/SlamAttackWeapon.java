package game.subweapon.nonportableweapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.subweapon.skills.AOEAttack;

/**
 * SlamAttackWeapon. Is not droppable. Used by hostiles to allow weapon skills
 * Created by:
 * @author Charlene
 */
public class SlamAttackWeapon extends WeaponItem {

    /**
     * Damage number of weapon
     */
    private int damage;

    /**
     * String verb represents how the weapon attacks I.e: Slam, slashes, bites
     */
    private String verb;

    /**
     * Hit rate of weapon
     */
    private int hitRate;

    /**
     * Constructor. Calls super method to implement its name, display character, damage, verb and hit rate.
     * Disallow it from dropping
     * @param name
     * Name of weapon
     * @param damage
     * Damage of weapon
     * @param verb
     * Description of attack
     * @param hitRate
     * Chance to hit
     */
    public SlamAttackWeapon(String name, int damage, String verb, int hitRate) {
        super(name,' ',damage,verb,hitRate);
        this.damage=damage;
        this.verb=verb;
        this.hitRate=hitRate;
        portable=false;


    }

    /**
     * Method getSkill to access SlamAttack. Slam Attack: AOE Attack
     * @param target
     * Actor that is receiving the damage
     * @param direction
     * Direction of attack
     *
     * @return SlamAttack
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new AOEAttack(this, "slams");
    }

    /**
     * Method GetDamage to return damage number of weapon
     * @return damage number
     */
    @Override
    public int damage() {
        return damage;
    }

    /**
     * Method verb to return verb to describe attack
     * @return verb, String
     */
    @Override
    public String verb() {
        return verb;
    }

    /**
     * Method chanceToHit to hit rate of weapon
     * @return hitRate, int
     */
    @Override
    public int chanceToHit() {
        return hitRate;
    }
}
