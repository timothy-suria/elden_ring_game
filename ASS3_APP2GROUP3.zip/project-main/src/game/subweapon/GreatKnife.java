package game.subweapon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.interfaces.Purchasable;
import game.interfaces.Sellable;
import game.Utils.enums.Status;
import game.subweapon.skills.QuickstepAction;
/**
 * Great knife Weapon Item. Is purchasable, is sellable. Has the weapon skill Quick step: Attacks and move back
 * Created by:
 * @author Charlene
 * Modified by:
 * @author Argya, Timothy
 */
public class GreatKnife extends WeaponItemUpgradable implements Sellable, Purchasable {

    private int damage;

    /**
     * Constructor. Calls super method to implement its name, display character, damage, verb and hit rate.
     * Adds the capability weapon item
     * Adds the capability sellable
     */

    public GreatKnife() {
        super("Great knife", '/', 75, "slash", 70);
        this.addCapability(Status.IS_WEAPON_ITEM);
        this.addCapability(Status.IS_SELLABLE);
        damage=75;
    }

    /**
     * Method getSkill to access Quickstep. Quick step: Attacks and move back
     * @param target
     * Actor that is receiving the damage
     * @param direction
     * Direction of attack
     *
     * @return Quickstep Action
     */
    public Action getSkill(Actor target, String direction){
        return new QuickstepAction(target,direction,this);

    }


    /**
     * Method purchaseRuneValue to return buying price of this item
     * @return 3500, buying price of weapon from trader
     */
    @Override
    public int purchaseRuneValue() {
        return 3500;
    }


    /**
     * Method hasCapability to return if this class represents is a weapon item
     * @return Boolean True if looking for a weapon item.
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return super.hasCapability(isWeaponItem);
    }

    /**
     * Method sellRuneValue to return selling price of this item
     * @return 350, selling price of weapon from trader
     */
    @Override
    public int sellRuneValue() {
        return 350;
    }

    /**
     * Static Method GetDamage to return damage number of weapon
     * @return 75, damage number of weapon
     */
    public int damage(){
        return damage;
    }
    /**
     * Static Method GetHitRate to return chance to hit
     * @return 70, weapon hits 70% of the time
     */
    public static int GetHitRate(){
        return 70;
    }

}
