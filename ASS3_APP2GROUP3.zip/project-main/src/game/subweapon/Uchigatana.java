package game.subweapon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.interfaces.Purchasable;
import game.interfaces.Sellable;
import game.Utils.enums.Status;
import game.subweapon.skills.UnsheatheAction;
/**
 * Uchigatana Weapon Item. Is purchasable, is sellable. Has the weapon skill Unsheathe: Attacks twice for lower chance of hitting
 * Created by:
 * @author Charlene
 * Modified by:
 * @author Argya, Timothy
 */
public class Uchigatana extends WeaponItemUpgradable implements Sellable, Purchasable {

    int damage=115;
    int hitRate=80;
    /**
     * Constructor. Calls super method to implement its name, display character, damage, verb and hit rate.
     * Adds the capability weapon item
     * Adds the capability sellable
     */
    public Uchigatana() {
        super("Uchigatana", ')', 115, "slashes", 80);
        this.addCapability(Status.IS_WEAPON_ITEM);
        this.addCapability(Status.IS_SELLABLE);
    }

    /**
     * Method getSkill to access UnsheatheAction. Unsheathe: Attacks twice for lower chance of hitting
     * @param target
     * Actor that is receiving the damage
     * @param direction
     * Direction of attack
     *
     * @return UnsheatheAction
     */
    public Action getSkill(Actor target, String direction){

        return new UnsheatheAction(target,direction,this );
    }

    /**
     * Method purchaseRuneValue to return buying price of this item
     * @return 5000, buying price of weapon from trader
     */
    @Override
    public int purchaseRuneValue() {
        return 5000;
    }

    /**
     * Method hasCapability to return if this class represents is a weapon item
     * @return Boolean True if looking for a weapon item.
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return super.hasCapability(isWeaponItem);
    }

    /**
     * Method sellRuneValue to return selling price of this item
     * @return 500, selling price of weapon from trader
     */
    @Override
    public int sellRuneValue() {
        return 500;
    }

    /**
     * Static Method GetDamage to return damage number of weapon
     * @return 115, damage number of weapon
     */
    public int damage(){
        return 115;
    }
}
