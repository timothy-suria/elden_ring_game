package game.subweapon.skills;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.Utils.RandomNumberGenerator;
import game.subactions.DeathAction;
import game.subweapon.GreatKnife;


import java.util.Random;
/**
 * Great knife Weapon Skill, Quick step. Attacks and move back
 * Created by:
 * @author Charlene
 */
public class QuickstepAction extends Action {
    /**
     * Direction of attack
     */
    private String direction;

    /**
     * The Actor that is to be attacked
     */
    private Actor target;

    /**
     * Damage number of weapon
     */
    private int damage;
    private Weapon weapon;

    /**
     * Constructor
     * @param target
     * Actor that is receiving the damage
     * @param direction
     * Direction of attack
     */
    public QuickstepAction(Actor target, String direction, Weapon heldWeapon) {
        this.target = target;
        this.direction = direction;
        weapon=heldWeapon;
        damage= heldWeapon.damage();
    }

    /**
     * method execute, returns a string and hurts the target. Will also death action if needed
     * @param actor
     * Actor that is doing the skill
     * @param map
     * Direction of attack
     *
     * @return result, return a string of what even has happened
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (!(RandomNumberGenerator.getRandomInt(100) < GreatKnife.GetHitRate())) {

            return actor + " misses " + target + " and evades.";
        }

        String result = actor + " " + "slashes " + target + " for " + damage + " damage and evades.";
        target.hurt(damage);
        if (!target.isConscious()) {
            result += new DeathAction(actor).execute(target, map);
        }

        Location currentLocation=map.locationOf(actor);
        for (Exit exit : currentLocation.getExits()) {
            Location destination = exit.getDestination();
            if (destination.getGround().canActorEnter(actor)&& !destination.containsAnActor()) {
                map.moveActor(actor,destination);
                result=result+actor+" evaded to new location. \n";
                return result; }}
        result=result+" Evade failed. No possible places to move to.";
        return result;
    }

    /**
     * method menuDescription, string to describe the skill in the menu
     * @param actor
     * Actor that is doing the skill
     * @return result, string of what even has happened
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " attacks " + target + " at " + direction + " by stabbing with their great knife and jumping back.";
    }
}