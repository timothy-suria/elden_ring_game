package game.subweapon.skills;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.Utils.RandomNumberGenerator;
import game.subactions.AttackAction;
import game.subactions.DeathAction;

/**
 * SlamAttack. Weapon skill of Slam attack action
 * Created by:
 * @author Charlene
 */
public class AOEAttack extends AttackAction{

    /**
     * Weapon type
     */
    private Weapon weapon;

    /**
     * Damage number of weapon
     */
    private int damage;

    /**
     * Hit rate of weapon
     */
    private int hitRate;

    private String description;


    /**
     * Constructor
     * @param weapon
     * Weapon the AOE Attack is based off
     */
    public AOEAttack(Weapon weapon, String description) {
        super(null, String.valueOf(weapon));
        this.weapon = weapon;
        damage= weapon.damage();
        hitRate= weapon.chanceToHit();
        this.description=description;

    }

    /**
     * method execute, returns a string and hurts the target. Will also death action if needed
     * @param actor
     * Actor that is doing the skill
     * @param map
     * Direction of attack
     *
     * @return result, return a string of what even has happened
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        StringBuilder result= new StringBuilder();
        Location location = map.locationOf(actor);
        for (Exit exit : location.getExits()) {
            Location destination = exit.getDestination();
            if (destination.containsAnActor()) {
                Actor target = destination.getActor();
                if (target != actor) {
                    if (!(RandomNumberGenerator.getRandomInt(100) < hitRate)) {
                        result.append(actor).append(" ").append(description).append(" attack misses ").append(target).append(".\n");
                    }
                    else {
                        result.append(actor).append(" ").append(description).append(" and attacks ").append(target).append(" for ").append(damage).append(" damage.\n");
                        target.hurt(damage);
                        if (!target.isConscious()) {
                            result.append(new DeathAction(actor).execute(target, map));
                        }}
                }
            }

        }
        return result.toString();

    }

    /**
     * method menuDescription, string to describe the skill in the menu
     * @param actor
     * Actor that is doing the skill
     * @return result, string of what even has happened
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " performs a spinning attack with their " + weapon;
    }
}
