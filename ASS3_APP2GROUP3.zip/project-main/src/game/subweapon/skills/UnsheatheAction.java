package game.subweapon.skills;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.Utils.RandomNumberGenerator;
import game.subactions.DeathAction;
import game.subweapon.Uchigatana;

import java.util.Random;
/**
 * Uchigatana Weapon Skill, Unsheathe: Attacks twice with a lower hit chance
 * Created by:
 * @author Charlene
 * Modified by:
 * @author Argya
 */

public class UnsheatheAction extends Action {

    /**
     * Direction of attack
     */
    private String direction;

    /**
     * The Actor that is to be attacked
     */
    private Actor target;

    /**
     * Damage number of weapon
     */
    private int damage;

    /**
     * Constructor
     * @param target
     * Actor that is receiving the damage
     * @param direction
     * Direction of attack
     */
    public UnsheatheAction(Actor target, String direction, Weapon heldWeapon) {
        this.damage= heldWeapon.damage()*2;
        this.target = target;
        this.direction = direction;
    }

    /**
     * method execute, returns a string and hurts the target. Will also death action if needed
     * @param actor
     * Actor that is doing the skill
     * @param map
     * Direction of attack
     *
     * @return result, return a string of what even has happened
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (!(RandomNumberGenerator.getRandomInt(100) < 60)) {
            return actor + " misses " + target + ".";
        }

        String result = actor + " " + "slashes " + target + " for " + damage + " damage.";
        target.hurt(damage);
        if (!target.isConscious()) {
            result += new DeathAction(actor).execute(target, map);
        }

        return result;
    }
    /**
     * method menuDescription, string to describe the skill in the menu
     * @param actor
     * Actor that is doing the skill
     * @return result, string of what even has happened
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " attacks " + target + " at " + direction + " by unsheathing the Uchigatana.";
    }
}
