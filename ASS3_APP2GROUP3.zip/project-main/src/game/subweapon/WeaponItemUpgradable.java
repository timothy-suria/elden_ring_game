package game.subweapon;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.enums.Status;

/**
 * Class representing items that can be used as a weapon.
 * Created by:
 * @author Charlene
 */
public abstract class WeaponItemUpgradable extends WeaponItem {

	/**
	 * int per step. Change be changed in the future
	 */
	private int DamageIncreaseBase=10;

	/**
	 * Total increased damage
	 */
	private int DamageIncreaseTotal=0;

	/**
	 * Number of upgrades
	 */
	private int IncreaseNumbers;


	/**
	 * Constructor.
	 *
	 * @param name        name of the item
	 * @param displayChar character to use for display when item is on the ground
	 * @param damage      amount of damage this weapon does
	 * @param verb        verb to use for this weapon, e.g. "hits", "zaps"
	 * @param hitRate     the probability/chance to hit the target.
	 */
	public WeaponItemUpgradable(String name, char displayChar, int damage, String verb, int hitRate) {
		super(name, displayChar, damage, verb, hitRate);
		addCapability(Status.IS_UPGRADABLE);
		IncreaseNumbers=0;
	}
	/**
	 * Method damage()
	 * @return int representing damage total
	 */
	@Override
	public int damage() {
		return super.damage()+DamageIncreaseTotal;
	}

	/**
	 * Method IncreaseDamage()
	 * Increases the damage by 1 base step
	 */
	public void IncreaseDamage(){
		DamageIncreaseTotal=DamageIncreaseBase+DamageIncreaseTotal;
		IncreaseNumbers=IncreaseNumbers+1;
	}

	/**
	 * Method getIncreaseNumbers()
	 * @return IncreaseNumbers. Number of upgrades performed so far
	 */
	public int getIncreaseNumbers(){
		return IncreaseNumbers;
	}

	/**
	 * method toString()
	 * if there has been an upgrade
	 * @return String name + increase number, otherwise just the name of the weapon
	 */
	@Override
	public String toString(){
		if (IncreaseNumbers>0)
			return super.toString()+" +"+IncreaseNumbers;
		else{
			return super.toString();
		}
	}
}
