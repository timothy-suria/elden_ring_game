package game.subweapon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.interfaces.Sellable;
import game.Utils.enums.Status;
import game.subweapon.skills.AOEAttack;

/**

 Grossmesser is a type of weapon item that can be wielded by actors.

 It has a high base damage and a special attack called SpinningAttackAction that can be executed using getSkill().

 It also has the capability of being sold for a certain amount of runes.
 @author :timothy suria
 */
public class Grossmesser extends WeaponItemUpgradable implements Sellable {

    /**
     Constructor that initializes the name, displayChar, damage and verb of the weapon.
     It also adds the capabilities of being a weapon item and sellable.
     */
    public Grossmesser() {
        super("Grossmesser", '?', 115, "slashes", 85);
        this.addCapability(Status.IS_WEAPON_ITEM);
        this.addCapability(Status.IS_SELLABLE);
    }

    /**

     A function that returns a SpinningAttackAction object.
     @param target The actor being targeted by the spinning attack.
     @param direction The direction in which the spinning attack is being executed.
     @return a SpinningAttackAction object.
     */
    public Action getSkill(Actor target, String direction){

        return new AOEAttack(this, "slashes");
    }

    /**
     Overrides the hasCapability method to check if the weapon item has a specific capability.
     @param isWeaponItem The capability being checked.
     @return a boolean value indicating whether the weapon item has the specified capability or not.
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return super.hasCapability(isWeaponItem);
    }

    /**
     Returns the value of the weapon item when it is sold.
     @return an integer value indicating the value of the weapon item when it is sold.
     */
    @Override
    public int sellRuneValue() {
        return 100;
    }
}
