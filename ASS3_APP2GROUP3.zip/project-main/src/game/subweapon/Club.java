package game.subweapon;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.interfaces.Purchasable;
import game.interfaces.Sellable;
import game.Utils.enums.Status;

/**
 * A simple weapon that can be used to attack the enemy.
 * It deals 103 damage with 80% hit rate
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 * @author  Argya, Charlene
 *
 */
public class Club extends WeaponItemUpgradable implements Sellable, Purchasable {

    /**
     * Constructor for club item. Calls super method to implement its name, display character, damage, verb and hit rate.
     *Adds the capability weapon item
     *Adds the capability sellable
     */
    public Club() {
        super("Club", '!', 103, "bonks", 80);
        this.addCapability(Status.IS_WEAPON_ITEM);
        this.addCapability(Status.IS_SELLABLE);
    }

    @Override
    public void tick(Location currentLocation, Actor actor) {}

    /**
     * Method purchaseRuneValue to return buying price of this item
     * @return 600, buying price of weapon from trader
     */
    @Override
    public int purchaseRuneValue() {
        return 600;
    }

    /**
     * Method hasCapability to return if this class represents is a weapon item
     * @return Boolean True if looking for a weapon item.
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return super.hasCapability(isWeaponItem);
    }

    /**
     * Method sellRuneValue to return selling price of this item
     * @return 100, selling price of weapon from trader
     */
    @Override
    public int sellRuneValue() {
        return 100;
    }
}
