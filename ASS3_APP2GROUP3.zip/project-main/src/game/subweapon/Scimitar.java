package game.subweapon;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.interfaces.Purchasable;
import game.interfaces.Sellable;
import game.Utils.enums.Status;
import game.subweapon.skills.AOEAttack;

/**

 Scimitar is a type of weapon item that can be wielded by actors.

 It has a high base damage and a special attack called SpinningAttackAction that can be executed using getSkill().

 It also has the capability of being sold for a certain amount of runes.
 @author :timothy suria
 */
public class Scimitar extends WeaponItemUpgradable implements Purchasable,Sellable {
    private int damage;


    /**
     * Constructor. Calls super method to implement its name, display character, damage, verb and hit rate.
     * Adds the capability weapon item
     * Adds the capability sellable
     */
    public Scimitar() {
        super("Scimitar", 's', 118, "slashes", 88);
        this.addCapability(Status.IS_WEAPON_ITEM);
        this.addCapability(Status.IS_SELLABLE);
        damage=118;
    }

    /**

     A function that returns a SpinningAttackAction object.
     @param target The actor being targeted by the spinning attack.
     @param direction The direction in which the spinning attack is being executed.
     @return a SpinningAttackAction object.
     */
    public Action getSkill(Actor target, String direction){

        return new AOEAttack(this, "slashes");
    }


    /**
     Overrides the hasCapability method to check if the weapon item has a specific capability.
     @param isWeaponItem The capability being checked.
     @return a boolean value indicating whether the weapon item has the specified capability or not.
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return super.hasCapability(isWeaponItem);
    }

    @Override
    public int purchaseRuneValue() {
        return 600;
    }

    /**
     Returns the value of the weapon item when it is sold.
     @return an integer value indicating the value of the weapon item when it is sold.
     */
    @Override
    public int sellRuneValue() {
        return 100;
    }
    /**
     * Static Method GetDamage to return damage number of weapon
     * @return 118, damage number of weapon
     */
    public int damage(){
        return damage;
    }
    /**
     * Static Method GetDamage to return damage number of weapon
     * @return 88, damage number of weapon
     */
    public static int GetHitRate(){
        return 88;
    }
}