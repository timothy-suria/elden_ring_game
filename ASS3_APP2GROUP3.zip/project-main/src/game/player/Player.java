package game.player;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.displays.Menu;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.ResetManager;
import game.Utils.RuneManager;
import game.interfaces.Consumable;
import game.interfaces.Playable;
import game.interfaces.Resettable;
import game.classes.ClassMenu;
import game.classes.PlayerClass;
import game.Utils.enums.Status;
import game.subactions.AttackAction;
import game.subactions.ConsumeAction;
import game.subactions.DeathAction;
import game.subitems.FlaskOfCrimsonTears;

/**
 * Class representing the Player. It implements the Resettable interface.
 * It carries around a club to attack a hostile creature in the Lands Between.
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 * @author Argya, Charlene, Timothy
 *
 */
public class Player extends Actor implements Resettable, Playable {

	private final Menu menu = new Menu();

	private Location lastLocation = null;
	private Location deathLocation = null;
	private Location respawnLocation = null;


	/**
	 * Constructor. Creates player, adds weapon and item into inventory.
	 *
	 * @param name        Name to call the player in the UI
	 * @param displayChar Character to represent the player in the UI
	 * @param hitPoints   Player's starting number of hitpoints
	 */
	public Player(String name, char displayChar, int hitPoints) {
		super(name, displayChar, hitPoints);
		ClassMenu Menu= new ClassMenu();
		PlayerClass playerClass=Menu.showMenu();
		this.addCapability(Status.HOSTILE_TO_ENEMY);
		this.addCapability(Status.PLAYER);
		this.addWeaponToInventory(playerClass.getWeapon());
		int hitPointDif=playerClass.getStartingHealth()-hitPoints;
		this.increaseMaxHp(hitPointDif);

		this.addItemToInventory(new FlaskOfCrimsonTears());
		ResetManager.getInstance().registerResettable(this);

	}
	/**
	 * Method playTurn. Returns a selected action
	 *
	 * @param actions
	 * Actionlist so that actor can pick
	 * @param lastAction
	 * Handles last action
	 * @param map
	 * Game map
	 * @param display
	 * Display
	 *
	 * @return actions
	 *
	 * */
	@Override
	public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
		if(map.locationOf(this).getGround().hasCapability(Status.FATAL)){
			this.hurt(this.getMaxHp());
			return new DeathAction(this);
		}
		if(respawnLocation == null){
			setRespawnLocation(map.locationOf(this));
		}

		setLastLocation(map.locationOf(this));

		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();

		for (Item item : getItemInventory()) {
			if(item.hasCapability(Status.CONSUMABLE)){
				if(((Consumable) item).hasUses()){
					actions.add(new ConsumeAction(this, (Consumable) item));
				}
			}
		}

		// return/print the console menu
		display.println("Current number of Runes: "+ RuneManager.getRunes());
		display.println("Current health: "+this.hitPoints);
		return menu.showMenu(this, actions, display);
	}

	/**
	 * Method allowableActions. Returns the actions that can be performed on this actor
	 * @param direction
	 * Direction of this actor from otherActor
	 * @param otherActor
	 * Other actor which is performing the action
	 * @param map
	 * Game map containing all the actors
	 *
	 * @return actions, list of Actions that can be performed
	 */
	public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
		ActionList actions = new ActionList();
		if(otherActor.hasCapability(Status.HOSTILE_TO_PLAYER)){
			actions.add(new AttackAction(this, direction));
			if (!otherActor.getWeaponInventory().isEmpty()) {
				actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
				actions.add(otherActor.getWeaponInventory().get(0).getSkill(this,direction));
			}
			// HINT 1: How would you attack the enemy with a weapon?
		}
		return actions;
	}
/**
 * Method reset will reset the player's hitpoints
 */

	@Override
	public void reset(GameMap map) {
		hitPoints = maxHitPoints;
	}
	/**
	 * Method setLastLocation will set the player's lastlocation
	 */
	@Override
	public void setLastLocation(Location location) {
		lastLocation = location;
	}

	/**
	 * Method getLastLocation will get the player's location
	 * @return lastLocation
	 */
	@Override
	public Location getLastLocation(){
		return this.lastLocation;
	}

	/**
	 * Method setDeathLocation will set the player's death location
	 */
	@Override
	public void setDeathLocation(Location location) {
		deathLocation = location;
	}

	/**
	 * Method getDeathLocation will get the player's location
	 * @return deathLocation
	 */
	@Override
	public Location getDeathLocation(){
		return this.deathLocation;
	}

	/**
	 * Method setRespawnLocation will set the player's death location
	 */
	@Override
	public void setRespawnLocation(Location location) {
		respawnLocation = location;
	}

	/**
	 * Method getRespawnLocation will get the player's location
	 * @return respawnLocation
	 */
	@Override
	public Location getRespawnLocation(){
		return this.respawnLocation;
	}
}
