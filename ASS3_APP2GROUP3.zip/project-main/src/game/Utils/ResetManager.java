package game.Utils;

import edu.monash.fit2099.engine.positions.GameMap;
import game.interfaces.Resettable;

import java.util.ArrayList;
import java.util.List;

/**
 * A reset manager class that manages a list of resettables.
 * Created by:
 * @author Adrian Kristanto
 * Modified by: Timothy Suria
 *
 */
public class ResetManager {
    private List<Resettable> resettables;
    private static ResetManager instance;

    private ResetManager() {
        this.resettables = new ArrayList<>();
    }

    /**
     Runs the reset method for all Resettable objects registered with this ResetManager.
     @param map the GameMap to pass to the reset method
     */
    public void run(GameMap map) {
        for (Resettable resettable : resettables) {
            resettable.reset(map);
        }

    }

    /**
     Registers a Resettable object with this ResetManager.
     @param resettable the Resettable object to register
     */
    public void registerResettable(Resettable resettable) {
        resettables.add(resettable);
    }

    /**
     Removes a Resettable object from this ResetManager.
     @param resettable the Resettable object to remove
     */
    public void removeResettable(Resettable resettable) {
        resettables.remove(resettable);
    }

    /**
     Returns the instance of ResetManager, creating it if it doesn't exist.
     @return the instance of ResetManager
     */
    public static ResetManager getInstance(){
        if (instance == null){
            instance = new ResetManager();
        }
        return instance;
        }
}
