package game.Utils;

import edu.monash.fit2099.engine.positions.GameMap;
import game.interfaces.DeathOnlyReset;
import java.util.ArrayList;
import java.util.List;

/**
 * A Death reset manager class that manages a list of deathOnlyResets.
 * Created by:
 * @author Charlene
 *
 */
public class deathOnlyResetManager {
    private List<DeathOnlyReset> deathOnlyResets;
    private static deathOnlyResetManager instance;

    private deathOnlyResetManager() {
        this.deathOnlyResets = new ArrayList<>();
    }

    /**
     Runs the reset method for all DeathOnlyReset objects registered with this deathOnlyResets.
     @param map the GameMap to pass to the reset method
     */
    public void run(GameMap map) {
        for (DeathOnlyReset deathOnlyResets : deathOnlyResets) {
            deathOnlyResets.deathOnlyReset(map);
        }

    }

    /**
     Registers a DeathOnlyReset object with this deathOnlyResetManager.
     */
    public void registerDeathOnlyReset(DeathOnlyReset deathOnlyResetsItem) {
        deathOnlyResets.add(deathOnlyResetsItem);
    }

    /**
     Removes a DeathOnlyReset object from this deathOnlyResetManager.
     */
    public void removeDeathOnlyReset(DeathOnlyReset deathOnlyResetsItem) {
        deathOnlyResets.remove(deathOnlyResetsItem);
    }

    /**
     Returns the instance of deathOnlyResetManager, creating it if it doesn't exist.
     @return the instance of deathOnlyResetManager
     */
    public static deathOnlyResetManager getInstance(){
        if (instance == null){
            instance = new deathOnlyResetManager();
        }
        return instance;
        }
}
