package game.Utils.enums;

/**
 * Use this enum class to give `buff` or `debuff`.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * @author Argya, Charlene, Timothy
 */
public enum Status {
    HOSTILE_TO_ENEMY,
    HOSTILE_TO_PLAYER,
    IS_SELLABLE,
    RESPAWNABLE,
    RESETTABLE,
    RESTING,
    PLAYER,
    IS_WEAPON_ITEM,
    CONSUMABLE,
    SKELETON,
    CANINE,
    CRUSTACEAN,
    ALTERNATE_DEATH,
    DROPPED_RUNES,
    STORMVEIL,
    DEATH_RESET_ONLY,
    FATAL,
    REMEMBRANCE,
    IS_UPGRADABLE

}
