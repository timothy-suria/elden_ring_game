package game.Utils.enums;
/**
 * Use this enum class to give ground descriptors.
 * Created by:
 * @author Charlene
 */
public enum CardinalDirection {
    EAST,
    WEST
}
