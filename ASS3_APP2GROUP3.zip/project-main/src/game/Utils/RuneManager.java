package game.Utils;

/**
 * Class representing the Player's rune count.
 * Created by:
 * @author Argya
 */

public class RuneManager {
    /**
     * The amount/number of Runes the Player has
     */
    private int runeAmount = 0;
    private static RuneManager instance;

    /**
     * Modify the Player's rune count by a certain value. Takes negative input to reduce.
     * @param amount the number of runes to add (or remove if negative)
     */
    public static void modifyRunes(int amount){
        RuneManager.getInstance().runeAmount = RuneManager.getInstance().runeAmount + amount;
    }

    /**
     * Gets the amount of runes the Player has
     * @return the amount of runes the Player has
     */
    public static int getRunes(){
        return RuneManager.getInstance().runeAmount;
    }

    /**
     * Sets the amount of runes the Player has
     * @param amount the amount of runes to set
     */
    public static void setRunes(int amount){
        RuneManager.getInstance().runeAmount = amount;
    }

    /**Returns instance of RuneManager, create if it hasn't been created
     * @return RuneManager
     * */
    public static RuneManager getInstance(){
        if (instance == null){
            instance = new RuneManager();
        }
        return instance;
    }
}
