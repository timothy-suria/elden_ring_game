package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.*;
import game.Utils.FancyMessage;
import game.Utils.RuneManager;
import game.enemies.GiantCrab;
import game.enemies.GiantDog;
import game.environments.*;
import game.maps.*;
import game.player.Player;
import game.subitems.GoldenRunes;
import game.subitems.RemembranceOfTheGrafted;
import game.traders.FingerReaderEnia;
import game.traders.Kale;

/**
 * The main class to start the game.
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 *
 */
public class Application {

	public static void main(String[] args) {

		World world = new World(new Display());

		GameMap limgrave = new Limgrave().getGameMap();
		GameMap roundTable = new RoundTable().getGameMap();
		GameMap stormveilCastle = new StormveilCastle().getGameMap();
		GameMap bossRoom = new BossRoom().getGameMap();

		MapManager.setGoldenFogDoor(limgrave, 35, 12, "Roundtable Hold", roundTable.at(9, 9));
		MapManager.setGoldenFogDoor(limgrave, 74, 12, "Stormveil Castle", stormveilCastle.at(2, 1));


		MapManager.setGoldenFogDoor(roundTable, 9, 10, "Limgrave", limgrave.at(36, 10));


		MapManager.setGoldenFogDoor(stormveilCastle, 1, 1, "Limgrave", limgrave.at(33, 11));
		MapManager.setGoldenFogDoor(stormveilCastle, 37, 23, "Boss Room", bossRoom.at(20, 7));

		MapManager.setGoldenFogDoor(bossRoom, 18, 8, "Stormveil Castle", stormveilCastle.at(37, 21));

		bossRoom.at(10, 5).addItem(new RemembranceOfTheGrafted());
		limgrave.at(55, 8).addItem(new GoldenRunes());
		limgrave.at(5, 16).addItem(new GoldenRunes());

		world.addGameMap(limgrave);
		world.addGameMap(roundTable);
		world.addGameMap(stormveilCastle);
		world.addGameMap(bossRoom);

		limgrave.addActor(new Kale(), limgrave.at(38, 11));
		roundTable.addActor(new FingerReaderEnia(), roundTable.at(3, 5));

		// BEHOLD, ELDEN RING
		for (String line : FancyMessage.ELDEN_RING.split("\n")) {
			new Display().println(line);
			try {
				Thread.sleep(200);
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}


		// HINT: what does it mean to prefer composition to inheritance?
		Player player = new Player("Tarnished", '@', 300);
		//world.addPlayer(player, gameMap.at(36, 10));
		world.addPlayer(player, limgrave.at(36, 10));
		RuneManager.setRunes(4000);
		new EastGroundFactory(limgrave);
		new EastGroundFactory(limgrave);




		world.run();
	}
}
