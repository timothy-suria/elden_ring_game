package game.enemies;


import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.RandomNumberGenerator;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;
import game.behaviours.WanderBehaviour;
import game.subweapon.nonportableweapons.SlamAttackWeapon;
import game.Utils.enums.Status;
import game.subactions.AttackAction;
import game.subweapon.skills.AOEAttack;

import java.util.*;

/**
 * Enemy GiantDog. Enemy that spawns from gust of wind and can slam attack
 * Created by:
 * @author Timothy
 * Modified by:
 * @author Charlene
 */

public class GiantDog extends Hostile implements Resettable {
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    private int runes;

    private int damage = 314;
    private int hitChance = 90;

    private WeaponItem weapon;

    /**
     Constructs a new instance of GiantDog with the given name, display character, and hit points.

     Also sets its spawn chance, adds the CANINE capability, and assigns it a SlamAttackWeapon.
     */
    public GiantDog() {
        super("Giant Dog", 'G', 693);
        this.behaviours.put(999, new WanderBehaviour());
        setSpawnChance(4);
        this.runes = RandomNumberGenerator.getRandomInt(313,1808);
        addCapability(Status.CANINE);
        this.weapon=new SlamAttackWeapon("Head", damage,"slams",hitChance);
        addWeaponToInventory(weapon);

    }
    /**
     * Method allowableActions. Returns the actions that can be performed on this actor
     * @param direction
     * Direction of this actor from otherActor
     * @param otherActor
     * Other actor which is performing the action
     * @param map
     * Game map containing all the actors
     *
     * @return actions, list of Actions that can be performed
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY) || !(otherActor.hasCapability(Status.CANINE))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }

        }
        return actions;
    }


    /**
     * Method getIntrisctionWeapon.
     * @return InsrinsicWeapon
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(damage, "hits", hitChance);
    }

    /**
     * Method getWeapon.
     * @return Weapon
     */
    public Weapon getWeapon(){return weapon;}

    /**
     * Method getSkill.
     * @return slamAttack. AOE version of normal attack
     */
    public Action getSkill() {
        return new AOEAttack(weapon, "slams");
    }



}


