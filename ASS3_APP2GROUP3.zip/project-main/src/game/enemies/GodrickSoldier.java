package game.enemies;


import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.RandomNumberGenerator;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;
import game.behaviours.WanderBehaviour;
import game.subweapon.Grossmesser;
import game.subweapon.nonportableweapons.SlamAttackWeapon;
import game.Utils.enums.Status;
import game.subactions.AttackAction;
import game.subweapon.skills.AOEAttack;

import java.util.*;
/**
 * Enemy GodrickSoldier, spawns in stormveil castle and has a grossmesser weapon
 * Created by:
 * @author Timothy
 */

public class GodrickSoldier extends Hostile implements Resettable {
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     Constructs a new instance of GodrickSoldier with the given name, display character, and hit points.

     Also sets its spawn chance, adds the STORMVEIL capability, and assigns it a Grossmesser weapon.
     */
    public GodrickSoldier() {
        super("GodrickSoldier", 'p', 198);
        this.behaviours.put(999, new WanderBehaviour());
        setSpawnChance(45);
        addWeaponToInventory(new Grossmesser());
        addCapability(Status.STORMVEIL);

        this.setRunes(RandomNumberGenerator.getRandomInt(38,70));
    }

    /**
     * Method allowableActions. Returns the actions that can be performed on this actor
     * @param direction
     * Direction of this actor from otherActor
     * @param otherActor
     * Other actor which is performing the action
     * @param map
     * Game map containing all the actors
     *
     * @return actions, list of Actions that can be performed
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY) || !(otherActor.hasCapability(Status.STORMVEIL))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }

        }
        return actions;
    }

    /**
     * Method getIntrisctionWeapon.
     * @return InsrinsicWeapon
     */

    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(101, "hits", 93);
    }

    /**
     * Method getWeapon()
     * @return weapon, new Grossmesser
     */
    public Weapon getWeapon(){
        return new Grossmesser();
    }







}


