package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.interfaces.Resettable;

import game.Utils.enums.Status;
import game.subactions.AttackAction;
import game.subactions.DespawnAction;
import game.subactions.ShowTextAction;

/**

 this class is an ability of skeletons where once they die, they turn into a pile of bones and can be revived within
 3 turns if the pile is not attacked.
 Created by:
 @author timothy suria
 Modified by:
 @author Argya
 */
public class PileOfBones extends Hostile implements Resettable {
    private char skeletonType;
    private int turnRevival;

    /**
     * Constructor for PileOfBones.
     *
     * @param skeletonSymbol the character representing the type of skeleton this PileOfBones will revive into
     * @param runes the number of runes required to defeat this enemy
     */
    public PileOfBones(char skeletonSymbol, int runes) {
        super("Pile Of Bones",'X', 1);
        this.setRunes(runes);
        this.turnRevival=3;
        this.skeletonType=skeletonSymbol;
    }

    /**
     * The playTurn method for PileOfBones, which determines what action this enemy will take on its turn.
     * If turnRevival is 0, it will despawn and revive into a different type of skeleton based on its skeletonType.
     * Otherwise, it will return a ShowTextAction indicating how many turns until it revives.
     *
     * @param actions the collection of possible Actions for this Actor
     * @param lastAction the Action this Actor took last turn
     * @param map the map containing the Actor
     * @param display the I/O object to which messages may be written
     * @return the valid action that can be performed in that iteration
     */
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        turnRevival--;
        if (turnRevival == 0){
            Location deathLocation=map.locationOf(this);
            new DespawnAction().execute(this, map);
            switch(skeletonType){
                case 'q':
                    map.addActor(new HeavySkeletalSwordsman(), deathLocation);
                break;
                case 'b':
                    map.addActor(new SkeletalBandit(), deathLocation);
                    break;
                default:
                    break;
            }

        }
        if(turnRevival > 0){
            return new ShowTextAction(turnRevival + " turn(s) until "+ name + " revives...");
        } else{
            return new ShowTextAction(name + " has revived!");
        }

    }

    /**
     * Determines the list of allowable actions for PileOfBones when it is adjacent to another actor.
     * It can attack if the other actor is not a friendly skeleton, and it can also use any weapon it picks up.
     *
     * @param otherActor the Actor adjacent to this PileOfBones
     * @param direction the direction from this Actor to the other Actor
     * @param map the map containing both Actors
     * @return the list of allowable actions for this PileOfBones
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)||!(otherActor.hasCapability(Status.SKELETON))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }

        }
        return actions;
    }
}
