package game.enemies;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.Utils.RandomNumberGenerator;
import game.Utils.enums.Status;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;
import game.behaviours.WanderBehaviour;
import game.subactions.AttackAction;

import java.util.HashMap;
import java.util.Map;

/**

 Lone wolf is an enemy in the game that is spawned in gust of wind. this class defines
 its stats and abilities
 Created by:
 @author timothy suria
 */
public class LoneWolf extends Hostile implements Resettable {
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     Constructs a new instance of LoneWolf with the given name, display character, and hit points.

     Also sets its spawn chance, adds the CANINE capability
     */
    public LoneWolf() {
        super("Lone Wolf", 'h', 102);
        this.behaviours.put(999, new WanderBehaviour());
        setSpawnChance(33);
        addCapability(Status.CANINE);

        this.setRunes(RandomNumberGenerator.getRandomInt(55,1470));

    }

    /**
     * Determines the list of allowable actions for LoneWolf when it is adjacent to another actor.
     *
     * @param otherActor the Actor adjacent to this actor
     * @param direction the direction from this Actor to the other Actor
     * @param map the map containing both Actors
     * @return the list of allowable actions for this actor
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY) || !(otherActor.hasCapability(Status.CANINE))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));

            }

        }
        return actions;
    }

    /**
     * Method getIntrisctionWeapon.
     * @return InsrinsicWeapon
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(97, "bites", 95);
    }


}

