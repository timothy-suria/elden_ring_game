package game.enemies;


import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.RandomNumberGenerator;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;
import game.behaviours.WanderBehaviour;
import game.subweapon.nonportableweapons.SlamAttackWeapon;
import game.Utils.enums.Status;
import game.subactions.AttackAction;
import game.subweapon.skills.AOEAttack;

import java.util.*;
/**
 * Enemy GiantCrayfish. Enemy that spawns from puddles of water and can slam attack
 * Created by:
 * @author Timothy
 * Modified by:
 * @author Charlene
 */

public class GiantCrayfish extends Hostile implements Resettable {
    private Map<Integer, Behaviour> behaviours = new HashMap<>();
    private int runes;
    private int damage = 527;
    private int hitChance = 100;

    private WeaponItem weapon;

    /**
     Constructs a new instance of GiantCrayFish with the given name, display character, and hit points.

     Also sets its spawn chance, adds the CRUSTACEAN capability, and assigns it a SlamAttackWeapon.
     */
    public GiantCrayfish() {
        super("Giant Crayfish", 'R', 4803);
        this.behaviours.put(999, new WanderBehaviour());
        setSpawnChance(1);
        this.runes = RandomNumberGenerator.getRandomInt(500,2374);
        addCapability(Status.CRUSTACEAN);
        this.weapon=new SlamAttackWeapon("Giant pinchers",damage,"attacks",hitChance);
        addWeaponToInventory(weapon);
    }

    /**
     * Method allowableActions. Returns the actions that can be performed on this actor
     * @param direction
     * Direction of this actor from otherActor
     * @param otherActor
     * Other actor which is performing the action
     * @param map
     * Game map containing all the actors
     *
     * @return actions, list of Actions that can be performed
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY) || !(otherActor.hasCapability(Status.CRUSTACEAN))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }

        }
        return actions;
    }


    /**
     * Method getIntrisctionWeapon.
     * @return InsrinsicWeapon
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(527, "attacks", 100);
    }

    /**
     * Method getWeapon.
     * @return Weapon
     */
    public Weapon getWeapon(){return weapon;}

    /**
     * Method getSkill.
     * @return slamAttack. AOE version of normal attack
     */
    public Action getSkill() {
        return new AOEAttack(weapon,"slams");
    }


}



