package game.enemies;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Utils.RandomNumberGenerator;
import game.Utils.deathOnlyResetManager;
import game.interfaces.DeathOnlyReset;
import game.classes.PlayerClass;
import game.Utils.enums.Status;
import game.subactions.AttackAction;
import game.subactions.DespawnAction;
import game.subitems.FlaskOfCrimsonTears;

/**
 * Class representing the Invader. It implements the DeathOnlyReset interface.
 * It can be of from any of the playerclasses
 * Created by:
 * @author Charlene
 */
public class Invader extends Hostile implements DeathOnlyReset {

    /**
     * Constructs a new Hostile object with the given name, display character and hit points.
     */
    public Invader(PlayerClass classType) {
        super(classType.getClassName(), 'ඞ', classType.getStartingHealth());
        this.addCapability(Status.HOSTILE_TO_PLAYER);
        this.removeCapability(Status.RESETTABLE);
        this.addCapability(Status.DEATH_RESET_ONLY);
        this.addWeaponToInventory(classType.getWeapon());
        int hitPointDif=classType.getStartingHealth()-hitPoints;
        this.increaseMaxHp(hitPointDif);
        this.setRunes(RandomNumberGenerator.getRandomInt(1358 ,5578 ));
        this.addItemToInventory(new FlaskOfCrimsonTears());
        deathOnlyResetManager.getInstance().registerDeathOnlyReset(this);

    }



    /**
     * Method allowableActions. Returns the actions that can be performed on this actor
     * @param direction
     * Direction of this actor from otherActor
     * @param otherActor
     * Other actor which is performing the action
     * @param map
     * Game map containing all the actors
     *
     * @return actions, list of Actions that can be performed
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }

        }
        return actions;
    }
    /**
     * Method reset will leave it be
     */

    @Override
    public void reset(GameMap map) {

    }

    /**
     * Method deathOnlyReset will despawn invader
     */
    @Override
    public void deathOnlyReset(GameMap map) {new DespawnAction().execute(this, map);

    }
}
