package game.enemies;


import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.Utils.RandomNumberGenerator;
import game.Utils.enums.Status;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;
import game.behaviours.WanderBehaviour;
import game.subactions.AttackAction;
import game.subweapon.Scimitar;

import java.util.*;

/**

 Skeletal Bandit is an enemy in the game that is spawned in graveyard on the east
 side of the map and has the weapon Scimitar equipped which has a special spinning attack ability. this class defines
 its stats and abilities
 Created by:
 @author timothy suria
 Modified by
 @author Argya, Charlene
 */
public class SkeletalBandit extends Hostile implements Resettable {
    private boolean bonePile = true;
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     Constructs a new instance of SkeletalBandit with the given name, display character, and hit points.

     Also sets its spawn chance, adds the SKELETON capability, and assigns it a weapon Scimitar with spin attack skill
     */
    public SkeletalBandit() {
        super("Skeletal Bandit", 'b', 184);
        this.behaviours.put(999, new WanderBehaviour());
        setSpawnChance(27);
        this.setRunes(RandomNumberGenerator.getRandomInt(35,892));
        addWeaponToInventory(new Scimitar());
        addCapability(Status.SKELETON);

    }
    /**
     * Determines the list of allowable actions for SkeletalBandit when it is adjacent to another actor.
     *
     * @param otherActor the Actor adjacent to this actor
     * @param direction the direction from this Actor to the other Actor
     * @param map the map containing both Actors
     * @return the list of allowable actions for this actor
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY) || !(otherActor.hasCapability(Status.SKELETON))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));

            }

        }
        return actions;
    }

    /**
     * Method getIntrisctionWeapon.
     * @return InsrinsicWeapon
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(115, "attacks", 85);
    }
    /**
     * Method getWeapon(), returns weapon object
     * @return Scimitar
     */
    public Weapon getWeapon(){return new Scimitar();}

}


