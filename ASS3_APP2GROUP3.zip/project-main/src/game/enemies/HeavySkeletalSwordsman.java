package game.enemies;


import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.Utils.RandomNumberGenerator;
import game.Utils.enums.Status;
import game.interfaces.AlternateDeathCapable;
import game.interfaces.Behaviour;
import game.interfaces.Resettable;
import game.behaviours.WanderBehaviour;
import game.subactions.AttackAction;
import game.subactions.DespawnAction;
import game.subweapon.Grossmesser;

import java.util.*;

/**

 Heavy skeletal swordsman is an enemy in the game that is spawned in graveyard and has
 a weapon Grossmesser equipped that has a spinning attack ability this class defines
 its stats and abilities
 Created by:
 @author timothy suria
 Modified by
 @author Charlene
 */
public class HeavySkeletalSwordsman extends Hostile implements Resettable, AlternateDeathCapable {
    private boolean bonePile = true;
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     Constructs a new instance of HeavySkeletalSwordsman with the given name, display character, and hit points.

     Also sets its spawn chance, adds the SKELETON capability, and assigns it a weapon Grossmesser with spin attack skill
     */
    public HeavySkeletalSwordsman() {
        super("Heavy Skeletal Swordsman", 'q', 153);
        this.behaviours.put(999, new WanderBehaviour());
        setSpawnChance(33);
        addWeaponToInventory(new Grossmesser());
        addCapability(Status.SKELETON);
        addCapability(Status.ALTERNATE_DEATH);
        this.setRunes(RandomNumberGenerator.getRandomInt(35,892));
    }

    /**
     * Determines the list of allowable actions for HeavySkeletalSwordsman when it is adjacent to another actor.
     * @param otherActor the Actor adjacent to this actor
     * @param direction the direction from this Actor to the other Actor
     * @param map the map containing both Actors
     * @return the list of allowable actions for this actor
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)||!(otherActor.hasCapability(Status.SKELETON))){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }

        }
        return actions;
    }

    /**
     * Method getIntrisctionWeapon.
     * @return InsrinsicWeapon
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(115, "attacks", 85);
    }

    /**
     * Method getWeapon()
     * @return weapon, new Grossmesser
     */
    public Weapon getWeapon(){
        return new Grossmesser();
    }

    /**
     Transforms the actor into a pile of bones when it dies.
     If the actor has already transformed into a bone pile, it will despawn instead.
     @param map the map on which the actor is located
     */
    public void becomeBonePile(GameMap map) {
        if (bonePile) {
            Location deathLocation=map.locationOf(this);
            new DespawnAction().execute(this, map);

        map.addActor(new PileOfBones('q', this.getRunes()), deathLocation);

    }
        else {
            new Display().println(this + " has died.");
        new DespawnAction().execute(this, map);
    }
    }

    /**
     * Method alternateDeath(). Alternative death for HeavySkeletalSwordman as they turn into a bonepile when they die
     * @param map
     * Game map where the actors are located
     */
    @Override
    public void alternateDeath(GameMap map) {
        becomeBonePile(map);
    }

    /**
     * Method alternateDescription(). Alternative death message
     * @param actor
     * Game map where the actors are located
     * @return String. Describes death
     */
    @Override
    public String alternateDescription(Actor actor) {
        return actor + " has been felled and turned into a pile of bones.";
    }
}




