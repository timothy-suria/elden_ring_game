package game.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import game.Utils.RandomNumberGenerator;
import game.Utils.ResetManager;
import game.Utils.enums.Status;
import game.interfaces.Behaviour;
import game.interfaces.NPCDropRunesCapable;
import game.interfaces.Resettable;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;
import game.subactions.AttackAction;
import game.subactions.DespawnAction;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;

import java.util.HashMap;
import java.util.Map;

/**
 * Hostile class that is inherited by all enemies
 * Created by:
 * @author Timothy suria
 * Modified by:
 * @author Argya
 */
public abstract class Hostile extends Actor implements Resettable, NPCDropRunesCapable {
    private int spawnChance;
    private int despawnChance;

    private int runes;

    private boolean isFollowing = false;

    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**

     Constructs a new Hostile object with the given name, display character and hit points.

     @param name the name of the Hostile

     @param displayChar the character used to display the Hostile on the game map

     @param hitPoints the number of hit points the Hostile starts with
     */
    public Hostile(String name, char displayChar, int hitPoints) {
        super(name,displayChar,hitPoints);
        // Sets up the Hostile's behaviours and despawn chance
        this.behaviours.put(999, new WanderBehaviour());
        despawnChance = 10;
        // Adds capabilities to the Hostile and registers it with the ResetManager
        addCapability(Status.HOSTILE_TO_PLAYER);
        addCapability(Status.RESETTABLE);
        ResetManager.getInstance().registerResettable(this);

    }

    public void setRunes(int runeValue){
        this.runes = runeValue;
    }

    public int getRunes(){
        return this.runes;
    }

    /**
     Determines and executes the Hostile's action for the current turn.

     @param actions the collection of possible Actions for this Hostile

     @param lastAction the Action this Hostile took last turn. Can do interesting things in conjunction with Action.getNextAction()

     @param map the map containing the Hostile

     @param display the I/O object to which messages may be written

     @return the valid action that can be performed in that iteration or null if no valid action is found
     */
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        Location here = map.locationOf(this);
        // Checks for nearby players to follow
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            if (destination.containsAnActor()){
                Actor checkActor = exit.getDestination().getActor();
                if (checkActor.hasCapability(Status.PLAYER)){
                    this.behaviours.put(1, new FollowBehaviour(checkActor));
                    this.behaviours.remove(999);
                    this.isFollowing = true;
                }
            }

        }
        // Despawns the Hostile if its despawn chance is reached and it is not following a player
        if ((RandomNumberGenerator.getRandomInt(100) <= despawnChance) && !isFollowing) {
            return new DespawnAction();
        }

        // try to find a behaviour that returns a non-null action
        for (Behaviour behaviour : behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if (action != null) {
                return action;
            }
        }

        // check if the actor has any weapons to use
        Actor target = null;
        for (WeaponItem weaponItem : this.getWeaponInventory()) {
            for (Exit exit : map.locationOf(this).getExits()) {
                Location destination = exit.getDestination();
                target = destination.getActor();
                if (target != null && map.locationOf(target).canActorEnter(target) && this != target) {
                    actions.add(new AttackAction(target, exit.getName(), weaponItem));
                }
            }
        }

        // if no behaviour returned an action, do nothing
        return new DoNothingAction();
    }

    /**
     Returns a list of allowable Actions that can be performed by another Actor against this Hostile.
     @param otherActor the Actor that is performing the Action against this Hostile
     @param direction the direction from the other Actor to this Hostile
     @param map the map containing both Actors
     @return a list of allowable Actions that can be performed by another Actor against this Hostile
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this, direction));
            }
        }
        return actions;
    }

    /**
     Sets the spawn chance of this Actor.
     @param spawnChance the new spawn chance of this Actor
     */
    public void setSpawnChance(int spawnChance) {
        this.spawnChance=spawnChance;
    }

    /**
     Returns a new IntrinsicWeapon with the specified damage, verb and hit rate.
     @param damage the amount of damage dealt by the IntrinsicWeapon
     @param verb the verb used to describe the action of the IntrinsicWeapon
     @param hitRate the hit rate of the IntrinsicWeapon
     @return a new IntrinsicWeapon with the specified damage, verb and hit rate
     */
    public IntrinsicWeapon getIntrinsicWeapon(int damage, String verb, int hitRate) {
        return new IntrinsicWeapon(damage,verb,hitRate);
    }

    /**
     Returns the skill of an object
     @return null
     */
    public Action getSkill() {
        return null;
    }

    /**
     Resets the state of this Actor, typically by removing it from the map through a DespawnAction.
     @param map the GameMap on which the Actor is located
     */
    @Override
    public void reset(GameMap map) {
        new DespawnAction().execute(this,map);

    }

}
