package game.enemies;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.RandomNumberGenerator;

import java.util.Objects;
/**
 * Enemy Manager
 * Created by:
 * @author Charlene
 * Debugged by:
 * @author Argya
 */
public class EnemyManager {

    /**
     * Actor Enemy, represents newly spawned enemy
     */
    private static Actor enemy;

    /**
     * Method spawnEnemy. Called when enemy is needed to be spawned. Will check if the location can spawn an enemy and if RNG permits
     * @param location
     * location to spawn enemy at
     * @param spawnChance
     * Chances that an enemy will spawn
     * @param cardinalDirection
     * Description of location type. Used to decide if the area is more dangerous
     */
    public static void spawnEnemy(Location location, double spawnChance, String cardinalDirection) {
        enemy=null;
        char symbol = location.getDisplayChar();
        if (!location.containsAnActor() && (RandomNumberGenerator.getRandomDouble() < spawnChance)){
            switch (symbol) {
                case 'n':

                       if (Objects.equals(cardinalDirection, "West"))
                        enemy = new HeavySkeletalSwordsman();
                       else
                           enemy = new SkeletalBandit();

                    break;
                case '&':
                        if (Objects.equals(cardinalDirection, "West"))
                            enemy = new LoneWolf();
                        else
                            enemy = new GiantDog();


                    break;
                case '~':
                        if (Objects.equals(cardinalDirection, "West"))
                            enemy = new GiantCrab();
                        else
                            enemy = new GiantCrayfish();

                    break;
                case '<':
                    enemy = new Dog();

                    break;
                case 'B':
                    enemy = new GodrickSoldier();

                    break;
                default:
                    enemy=null;
                    break;
            }
            if (enemy!=null)
                location.addActor(enemy);
            }
    }

}
