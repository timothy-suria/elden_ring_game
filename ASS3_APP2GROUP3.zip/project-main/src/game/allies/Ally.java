package game.allies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.RandomNumberGenerator;
import game.Utils.ResetManager;
import game.Utils.RuneManager;
import game.Utils.deathOnlyResetManager;
import game.Utils.enums.Status;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;
import game.classes.PlayerClass;
import game.enemies.Hostile;
import game.interfaces.Behaviour;
import game.interfaces.Consumable;
import game.interfaces.DeathOnlyReset;
import game.interfaces.Resettable;
import game.subactions.AttackAction;
import game.subactions.ConsumeAction;
import game.subactions.DespawnAction;
import game.subitems.FlaskOfCrimsonTears;

import java.util.HashMap;
import java.util.Map;

/**
 * Class representing the Ally. It implements the DeathOnlyReset interface.
 * It can be made from any of the player classes
 * Created by:
 * @author Charlene
 */
public class Ally extends Actor implements DeathOnlyReset {
    private Map<Integer, Behaviour> behaviours = new HashMap<>();


    /**
     * Constructs a new Ally object with the given name, display character and hit points.
     *
     */
    public Ally(PlayerClass classType) {
        super(classType.getClassName(), 'A', classType.getStartingHealth());
        this.addCapability(Status.HOSTILE_TO_ENEMY);
        this.removeCapability(Status.RESETTABLE);
        this.addCapability(Status.DEATH_RESET_ONLY);

        this.addWeaponToInventory(classType.getWeapon());
        int hitPointDif=classType.getStartingHealth()-hitPoints;
        this.increaseMaxHp(hitPointDif);
        this.behaviours.put(999, new WanderBehaviour());
        this.addItemToInventory(new FlaskOfCrimsonTears());
        deathOnlyResetManager.getInstance().registerDeathOnlyReset(this);


    }


    /**
     * Method playTurn. Returns a selected action
     *
     * @param actions
     * Actionlist so that actor can pick
     * @param lastAction
     * Handles last action
     * @param map
     * Game map
     * @param display
     * Display
     *
     * @return actions
     *
     * */
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {

        // try to find a behaviour that returns a non-null action
        for (Behaviour behaviour : behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if (action != null) {
                return action;
            }
        }

        // check if the actor has any weapons to use
        Actor target = null;
        for (WeaponItem weaponItem : this.getWeaponInventory()) {
            for (Exit exit : map.locationOf(this).getExits()) {
                Location destination = exit.getDestination();
                target = destination.getActor();
                if (target != null && map.locationOf(target).canActorEnter(target) && this != target) {
                    actions.add(new AttackAction(target, exit.getName(), weaponItem));
                }
            }
        }
        // if no behaviour returned an action, do nothing
        return new DoNothingAction();
    }


    /**
     * Method allowableActions. Returns the actions that can be performed on this actor
     * @param direction
     * Direction of this actor from otherActor
     * @param otherActor
     * Other actor which is performing the action
     * @param map
     * Game map containing all the actors
     *
     * @return actions, list of Actions that can be performed
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_PLAYER)){
            actions.add(new AttackAction(this, direction));
            if (!otherActor.getWeaponInventory().isEmpty()) {
                actions.add(new AttackAction(this, direction, otherActor.getWeaponInventory().get(0)));
                actions.add(otherActor.getWeaponInventory().get(0).getSkill(this,direction));
            }
            // HINT 1: How would you attack the enemy with a weapon?
        }
        return actions;
    }

    /**
     * Method reset will despawn ally
     */
    @Override
    public void deathOnlyReset(GameMap map) {new DespawnAction().execute(this, map);

    }
}
