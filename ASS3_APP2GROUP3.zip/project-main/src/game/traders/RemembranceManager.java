package game.traders;

import edu.monash.fit2099.engine.items.Item;
import game.subweapon.AxeOfGodrick;
import game.subweapon.GraftedDragon;

/**
 * A class to help facilitate using Remembrances
 *
 * created by:
 * @author Argya
 */
public class RemembranceManager {

    /**
     * Gets the possible items from the remembrance.
     * @param remembrance
     * @param option
     * @return the Item that a remembrance can be exchanged for
     */
    public static Item getRemembranceItem(Item remembrance, int option){

        String checkRemembrance = remembrance.toString();

        switch(checkRemembrance){
            case "Remembrance of the Grafted":
                //could use another layer of switch case here
                if(option == 1){
                    return new AxeOfGodrick();
                } else if(option == 2){
                    return new GraftedDragon();
                } else{
                    return null;
                }
            default:
                return null;

        }



    }

}
