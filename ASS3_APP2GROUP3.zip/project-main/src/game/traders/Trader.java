package game.traders;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.enums.Status;
import game.subactions.ItemUpgradeAction;
import game.subactions.PurchaseAction;
import game.subactions.SellAction;
import game.subactions.WeaponsUpgradeAction;

import java.util.ArrayList;
import java.util.List;

/**
 * An Actor representing a Trader that can buy and sell items
 */
public abstract class Trader extends Actor {

    /**
     * Constructor.
     *
     * @param name        the name of the Actor
     * @param displayChar the character that will represent the Actor in the display
     * @param hitPoints   the Actor's starting hit points
     */
    /**
     * The list of items the Trader can sell to a Player
     */
    private List<WeaponItem> purchasableInventory = new ArrayList<>();

    public List<WeaponItem> getPurchasableInventory(){
        return this.purchasableInventory;
    }


    /**
     * Add an item to the Trader's inventory that they can sell
     * @param purchasable
     */
    public void addSellable(WeaponItem purchasable) {
        purchasableInventory.add(purchasable);
    }

    /**
     * Constructor.
     *
     * @param name the name of the Trader
     * @param displayChar the character to be displayed on the map
     * @param hitPoints the health of the Trader
     */
    public Trader(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
    }

    /**
     * Returns a list of possible actions to be done to the Trader if the actor checking
     * for what actions are available is the/a Player. It then returns purchase actions based
     * on what is in the Trader's inventory, and returns sell actions based on what is in the
     * Player's inventory.
     *
     * @param otherActor the Actor that is interacting with the Trader
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return the list of actions
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.PLAYER)) {
            //add: for weapons in player inventory, add sellaction for that weapon

            for (int i = 0; i < purchasableInventory.size(); i++) {
                actions.add(new PurchaseAction(purchasableInventory.get(i), this));
            }

            for (int i = 0; i < otherActor.getItemInventory().size(); i++) {
                if (otherActor.getItemInventory().get(i).hasCapability(Status.IS_SELLABLE)) {
                    actions.add(new SellAction(otherActor.getItemInventory().get(i), this));
                }
                if (otherActor.getItemInventory().get(i).hasCapability(Status.IS_UPGRADABLE)) {
                    actions.add(new ItemUpgradeAction(otherActor.getItemInventory().get(i), this));
                }
            }

            for (int i = 0; i < otherActor.getWeaponInventory().size(); i++) {
                if (otherActor.getWeaponInventory().get(i).hasCapability(Status.IS_SELLABLE)) {
                    actions.add(new SellAction(otherActor.getWeaponInventory().get(i), this));
                    actions.add(new WeaponsUpgradeAction(otherActor.getWeaponInventory().get(i), this));
                }
            }
        }
        return actions;
    }
}
