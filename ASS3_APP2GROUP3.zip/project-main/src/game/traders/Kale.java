package game.traders;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.subweapon.Club;
import game.subweapon.GreatKnife;
import game.subweapon.Uchigatana;

/**
 * The class for the Merchant Kale. Kale can buy and sell weapons,
 * and can be found within safe locations that monsters can't access.
 * Created by:
 * @author Argya
 * Modified by:
 */
public class Kale extends Trader {

    /**
     * Constructor.
     *
     * Creates Merchant Kale and adds items to his inventory to be sold.
     */
    public Kale() {
        super("Kale", 'K', 100);
        this.addSellable(new Club());
        this.addSellable(new Uchigatana());
        this.addSellable(new GreatKnife());
    }

    /**
     * Kale does nothing on his turn at the moment.
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return new DoNothingAction()
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }



}
