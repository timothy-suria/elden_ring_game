package game.traders;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Utils.enums.Status;
import game.subactions.PurchaseAction;
import game.subactions.SellAction;
import game.subactions.SellRemembranceAction;

/**
 * The class for Finger Reader Enia. Enia can buy anything that can be sold, but
 * does not sell anything. Instead, the Player can exchange remembrances for certain
 * Items with this Trader.
 * Created by:
 * @author Argya
 */
public class FingerReaderEnia extends Trader {
    /**
     * Constructor.
     *
     * Creates Enia.
     */
    public FingerReaderEnia() {
        super("Finger Reader Enia", 'E', 100);
    }

    /**
     * Enia does nothing on her turn.
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return new DoNothingAction()
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();

    }

    /**
     * Returns a list of possible actions that can be done to Enia during her turn.
     * If the otherActor is a Player, then returns actions to exchange remembrances
     * and also to sell any sellables to her.
     * @param otherActor the Actor that is interacting with the Trader
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return the list of actions
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.PLAYER)) {

            for (int i = 0; i < otherActor.getItemInventory().size(); i++) {
                if (otherActor.getItemInventory().get(i).hasCapability(Status.REMEMBRANCE)) {
                    actions.add(new SellRemembranceAction(RemembranceManager.getRemembranceItem(otherActor.getItemInventory().get(i), 1), this, otherActor.getItemInventory().get(i)));
                    actions.add(new SellRemembranceAction(RemembranceManager.getRemembranceItem(otherActor.getItemInventory().get(i), 2), this, otherActor.getItemInventory().get(i)));
                }
            }

            for (int i = 0; i < otherActor.getItemInventory().size(); i++) {
                if (otherActor.getItemInventory().get(i).hasCapability(Status.IS_SELLABLE)) {
                    actions.add(new SellAction(otherActor.getItemInventory().get(i), this));
                }
            }

            for (int i = 0; i < otherActor.getWeaponInventory().size(); i++) {
                if (otherActor.getWeaponInventory().get(i).hasCapability(Status.IS_SELLABLE)) {
                    actions.add(new SellAction(otherActor.getWeaponInventory().get(i), this));
                }
            }


        }
        return actions;
    }

}
