package game.maps;

import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.GroundFactory;
import edu.monash.fit2099.engine.positions.Location;
import game.environments.*;

/**
 * A class to help create and manage maps.
 *
 * Created by:
 * @author Argya
 */
public class MapManager {

    /**
     * FancyGroundFactory that contains all the different types of Grounds that can be made
     */
    static FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(),new Graveyard(),
            new GustOfWind(), new PuddleOfWater(),new SiteOfLostGrace(), new Cage(), new Barrack(), new Cliff(), new SummonSign());

    /**
     * Method to return the FancyGroundFactory
     * @return FancyGroundFactory that contains all the different types of Grounds that can be made
     */
    public static FancyGroundFactory getGrounds(){
        return groundFactory;
    }

    /**
     * Method to place a Golden Fog Door on a map.
     * @param map the GameMap where the Fog Door is placed
     * @param x the x-coordinate of the Fog Door
     * @param y the y-coordinate of the Fog Door
     * @param dest the destination description of the Fog Door
     * @param loc the location where the Fog Door is placed (likely on another GameMap)
     */
    public static void setGoldenFogDoor(GameMap map, int x, int y, String dest, Location loc){
        map.at(x, y).setGround(new GoldenFogDoor(loc, dest));
    }

}
