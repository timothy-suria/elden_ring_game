package game.maps;

import edu.monash.fit2099.engine.positions.GameMap;
import game.interfaces.MapArea;

import java.util.Arrays;
import java.util.List;

/**
 * A class representing the RoundTable map area.
 * @author Timothy
 */
public class RoundTable implements MapArea {
    /**
     * List of strings representing the map layout.
     */
    List<String> mapList = Arrays.asList(
            "##################",
            "#________________#",
            "#________________#",
            "#________________#",
            "#________U_______#",
            "#________________#",
            "#________________#",
            "#________________#",
            "#________________#",
            "#________________#",
            "########___#######");

    /**
     * GameMap object representing the RoundTable map.
     */
    GameMap map = new GameMap(MapManager.getGrounds(), mapList);

    /**
     * Retrieves the RoundTable map.
     *
     * @return The GameMap object representing the RoundTable map.
     */
    @Override
    public GameMap getGameMap() {
        return map;
    }

}
