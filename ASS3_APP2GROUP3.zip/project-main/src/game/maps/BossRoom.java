package game.maps;

import edu.monash.fit2099.engine.positions.GameMap;
import game.interfaces.MapArea;

import java.util.Arrays;
import java.util.List;

/**
 * A class representing the BossRoom map area.
 * @author Timothy
 */
public class BossRoom implements MapArea {
    /**
     * List of strings representing the map layout.
     */
    List<String> mapList = Arrays.asList(
            "+++++++++++++++++++++++++",
            ".........................",
            "..=......................",
            ".........................",
            "............U............",
            ".........................",
            ".........................",
            ".........................",
            "+++++++++++++++++++++++++");

    /**
     * GameMap object representing the BossRoom map.
     */
    GameMap map = new GameMap(MapManager.getGrounds(), mapList);

    /**
     * Retrieves the BossRoom map.
     *
     * @return The GameMap object representing the BossRoom map.
     */
    @Override
    public GameMap getGameMap() {
        return map;
    }

}
