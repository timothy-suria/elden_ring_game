package game.subitems;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Utils.ResetManager;
import game.Utils.enums.Status;
import game.interfaces.Consumable;
import game.interfaces.Resettable;

/**
 * An Item representing the Flask of Crimson Tears
 * Created by:
 * @author Argya
 */
public class FlaskOfCrimsonTears extends Item implements Resettable, Consumable {
    /**
     * The maximum number of uses of the Flask.
     */
    private int maxUses = 2;
    /**
     * The current number of uses left of the Flask.
     */
    private int usesLeft = maxUses;
    /**
     * The amount of health healed by the Flask.
     */
    private int healAmount;

    /**
     * Constructor.
     *
     * Creates a Flask of Crimson Tears. Always begins with 2 charges/uses and
     * heals 200 health.
     */
    public FlaskOfCrimsonTears() {
        super("Flask of Crimson Tears", 'F', false);
        this.addCapability(Status.CONSUMABLE);
        this.addCapability(Status.IS_UPGRADABLE);
        this.healAmount = 200;
        ResetManager.getInstance().registerResettable(this);

    }

    /**
     * Consumes a charge/use of the flask to heal a user.
     * @param user
     * @return description of what happens upon using the flask. (ex: Uses flask and restores hp, or has no uses left)
     */
    public String consume(Actor user){
        if(this.hasUses()){
            user.heal(this.healAmount);
            this.usesLeft -= 1;
            return user + " uses a Flask of Crimson tears, restoring " + this.healAmount + " health.";
        } else{
            return "There are no uses left.";
        }
    }

    /**
     * Checks if the flask has any uses left
     * @return true/false if there are uses left in the flask
     */
    @Override
    public boolean hasUses() {
        return (this.usesLeft > 0);
    }

    @Override
    public void increaseMaxUse() {
        maxUses=maxUses+1;
        this.usesLeft+=1;
    }

    /**
     * Resets/refills the uses left of the flask.
     * @param map the current GameMap
     */
    @Override
    public void reset(GameMap map) {
        this.usesLeft = maxUses;
    }

}