package game.subitems;

import edu.monash.fit2099.engine.items.Item;
import game.Utils.enums.Status;
import game.subactions.RecoverRunesAction;

/**
 * An Item representing dropped runes on the ground.
 * Created by:
 * @author Argya
 * Modified by:
 */
public class DroppedRunes extends Item {
    /**
     * The amount of runes dropped on the ground
     */
    private int runeAmount;

    /**
     * Constructor.
     *
     * @param runes the amount of runes dropped
     */
    public DroppedRunes(int runes) {
        super("Runes", '$', false);
        addCapability(Status.DROPPED_RUNES);
        this.runeAmount = runes;
        this.addAction(new RecoverRunesAction(this));
    }

    /**
     * Gets the amount of runes dropped on the ground
     * @return the amount of runes dropped on the ground
     */
    public int getRuneAmount() {
        return runeAmount;
    }
}
