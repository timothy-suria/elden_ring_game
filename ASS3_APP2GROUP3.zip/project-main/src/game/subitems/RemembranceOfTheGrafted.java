package game.subitems;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.Utils.RandomNumberGenerator;
import game.Utils.RuneManager;
import game.Utils.enums.Status;
import game.interfaces.Sellable;

/**
 * A class representing the Remembrance of the Grafted.
 * Created by:
 * @author Argya
 */
public class RemembranceOfTheGrafted extends Item implements Sellable {

    /***
     * Constructor.
     *
     */
    public RemembranceOfTheGrafted() {
        super("Remembrance of the Grafted", 'O', true);
        this.addCapability(Status.REMEMBRANCE);
        this.addCapability(Status.IS_SELLABLE);
    }

    /**
     * Returns the value of the sellable
     * @return the rune value of the sellable
     */
    @Override
    public int sellRuneValue() {
        return 20000;
    }

    /**
     * Returns if it is a weapon item. not used in this class
     * @param isWeaponItem an ENUM Status
     * @return false
     */
    @Override
    public boolean hasCapability(Status isWeaponItem) {
        return false;
    }
}

