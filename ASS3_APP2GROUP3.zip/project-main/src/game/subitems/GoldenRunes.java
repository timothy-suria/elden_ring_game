package game.subitems;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.Utils.RandomNumberGenerator;
import game.Utils.RuneManager;
import game.Utils.enums.Status;
import game.interfaces.Consumable;

/**
 * A class representing Golden Runes
 * Created by:
 * @author Argya
 */
public class GoldenRunes extends Item implements Consumable {
    /***
     * Constructor.
     *
     */
    public GoldenRunes() {
        super("Golden Rune", '*', true);
        this.addCapability(Status.CONSUMABLE);
    }

    /**
     * When consumed, the Player gains a random amount of runes within range 200-10000
     * @param user The Actor that consumes the Consumable
     * @return A description of the actor consuming the rune
     */
    @Override
    public String consume(Actor user) {
        int gainedRunes = RandomNumberGenerator.getRandomInt(200, 10000);
        RuneManager.modifyRunes(gainedRunes);
        user.removeItemFromInventory(this);
        return user + " consumes the Golden Rune, gaining " + gainedRunes + " runes.";
    }

    /**
     * Returns whether or not the consumable has any uses left. Returns true as its always usable (only has 1 use, removed when used)
     * @return
     */
    @Override
    public boolean hasUses() {
        return true;
    }

    /**
     * Increases the max uses of the consumable. Is not used in this class
     */
    @Override
    public void increaseMaxUse() {
        //could be used if there is item stacking in the game
    }
}
