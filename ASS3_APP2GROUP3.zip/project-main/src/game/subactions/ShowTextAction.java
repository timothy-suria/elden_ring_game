package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * An Action to show text to be used instead of Do Nothing.
 * Created by:
 * @author Argya
 * Modified by:
 *
 */
public class ShowTextAction extends Action {

    /**
     * Text to be shown.
     */
    private String text;

    /**
     * Constructor.
     *
     * @param text The text to be shown.
     */
    public ShowTextAction(String text){
        this.text = text;
    }

    /**
     * When executed, it will return the text to be shown.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the text to be shown
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return text;
    }

    /**
     * Returns a blank String.
     *
     * @param actor The actor performing the action.
     * @return String
     */
    @Override
    public String menuDescription(Actor actor) {
        return "";
    }
}
