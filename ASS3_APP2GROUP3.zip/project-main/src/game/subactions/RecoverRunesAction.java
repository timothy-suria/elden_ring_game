package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.subitems.DroppedRunes;
import game.Utils.RuneManager;

/**
 * An Action to retrieve runes on the ground.
 * Created by:
 * @author Argya
 * Modified by:
 *
 */
public class RecoverRunesAction extends Action {
    /**
     * The DroppedRunes item on the ground
     */
    private DroppedRunes droppedRunes;

    /**
     * Constructor.
     *
     * @param droppedRunes The DroppedRunes item on the ground
     */
    public RecoverRunesAction(DroppedRunes droppedRunes){
        this.droppedRunes = droppedRunes;
    }

    /**
     * When executed, the rune count increases by the amount of runes dropped on the
     * ground. Then, it removes the dropped runes from the map.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return The result of the action. (The actor ahs received Runes of certain value)
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        RuneManager.modifyRunes(droppedRunes.getRuneAmount());
        map.locationOf(actor).removeItem(droppedRunes);
        return menuDescription(actor);
    }

    /**
     * Describes who retrieves the runes and the amount of runes.
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " retrieves Runes (value: "+droppedRunes.getRuneAmount()+")";
    }
}
