package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.enums.Status;
import game.traders.Trader;
/**
 * An Action to Exchange a Remembrance for an Item
 * Created by:
 * @author Argya
 * Modified by:
 *
 */
public class SellRemembranceAction extends Action {

    /**
     * The Remembrance to be given to the Trader
     */
    private Item remembrance;

    /**
     * The trader that is receiving the remembrance
     */
    private Trader trader;
    /**
     * The item being given by the Trader.
     */
    private Item givenItem;
    /**
     * The weapon being given by the Trader.
     */
    private WeaponItem givenWeapon;
    /**
     * Boolean to check if the thing being given is a Weapon
     */
    private boolean sellingWeapon = false;


    /**
     * Constructor.
     *
     * @param item The Item to be traded for the remembrance
     * @param seller The Trader being given the remembrance
     * @param remem The remembrance being traded for the item
     */
    public SellRemembranceAction(Item item, Trader seller, Item remem) {
        if(item.hasCapability(Status.IS_WEAPON_ITEM)){
            givenWeapon = (WeaponItem) item;
            sellingWeapon = true;
        } else{
            givenItem = item;
        }

        trader = seller;
        remembrance = remem;

    }

    /**
     * Constructor.
     *
     * @param item The WeaponItem to be traded for the remembrance
     * @param seller The Trader being given the remembrance
     * @param remem The remembrance being traded for the item
     */
    public SellRemembranceAction(WeaponItem item, Trader seller, Item remem) {
        givenWeapon = item;
        trader = seller;
        remembrance = remem;
        sellingWeapon = true;
    }

    /**
     *  When executed, it checks if the thing being exchanged for is a weapon or not. Then, it removes the remembrance
     *  and adds the exchanged item to the appropriate inventory.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the result of the selling, showing which actor sold what to who for how much.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if(sellingWeapon){
            actor.removeItemFromInventory(remembrance);
            actor.addWeaponToInventory(givenWeapon);
            return actor + " exchanges " + remembrance + " to " + trader + " for " + givenWeapon;
        } else{
            actor.removeItemFromInventory(remembrance);
            actor.addItemToInventory(givenItem);
            return actor + " exchanges " + remembrance + " to " + trader + " for " + givenItem;
        }


    }

    /**
     * Describes what remembrance the actor is exchanging with who for what
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        if(sellingWeapon){
            return actor + " exchanges " + remembrance + " to " + trader + " for " + givenWeapon;
        } else{
            return actor + " exchanges " + remembrance + " to " + trader + " for " + givenItem;
        }

    }
}
