package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.RuneManager;
import game.Utils.enums.Status;
import game.interfaces.Purchasable;
import game.subweapon.WeaponItemUpgradable;
import game.traders.Trader;

/**
 * Class WeaponsUpgradeAction. Upgrade a weapon if the material condition is met.
 * Created by:
 * @author Charlene
 */

public class WeaponsUpgradeAction extends Action {
    /**
     * The Weapon to be upgraded
     */
    private WeaponItem toBeUpgradedWeapon;
    /**
     * The trader that is upgrading
     */
    private Trader trader;

    /**
     * Constructor.
     *
     * @param item The Weapon to be upgraded
     * @param seller The trader that is upgrading
     */
    public WeaponsUpgradeAction(WeaponItem item, Trader seller) {
        toBeUpgradedWeapon = item;
        trader = seller;
    }

    /**
     *  When executed, check if the material cost has been met and then upgrade the weapon if it does.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the result of the upgrading attempt
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if(RuneManager.getRunes() > ((Purchasable) toBeUpgradedWeapon).purchaseRuneValue()){ //hardcoded atm. CHANGE
            if(toBeUpgradedWeapon.hasCapability(Status.IS_UPGRADABLE)){
                ((WeaponItemUpgradable) toBeUpgradedWeapon).IncreaseDamage();
                RuneManager.modifyRunes(-((Purchasable) toBeUpgradedWeapon).purchaseRuneValue());
                return actor + " bought an upgrade for " + toBeUpgradedWeapon + " from " + trader ;
            }
        }
        return actor + " does not have enough runes to purchase an upgrade";
    }

    /**
     * Describes what actor is upgraded and for how much.
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " upgrades " + toBeUpgradedWeapon + " for " + ((Purchasable) toBeUpgradedWeapon).purchaseRuneValue();
    }
}
