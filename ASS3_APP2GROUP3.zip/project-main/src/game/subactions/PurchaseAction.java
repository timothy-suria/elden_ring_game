package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.interfaces.Purchasable;
import game.Utils.RuneManager;
import game.Utils.enums.Status;
import game.traders.Trader;
/**
 * An Action to Purchase an Item
 * Created by:
 * @author Argya
 * Modified by:
 *
 */
public class PurchaseAction extends Action {
    /**
     * The Item to be purchased
     */
    private WeaponItem purchaseItem;
    /**
     * The Trader that is selling the weapon to the buyer
     */
    private Trader trader;

    /**
     * Constructor.
     *
     * @param item The Item to be purchased
     * @param seller The Trader that is selling the weapon to the buyer
     */
    public PurchaseAction(WeaponItem item, Trader seller) {
        purchaseItem = item;
        trader = seller;
    }

    /**
     * When executed, its checked if there are enough runes to buy the item or not. If there are,
     * then add the item to the customer's inventory and subtract the item's price from the
     * customer's (Player's) rune count.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the result of the purchase, ex: they don't have enough runes, bought the item
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if(RuneManager.getRunes() > ((Purchasable) purchaseItem).purchaseRuneValue()){
            if(purchaseItem.hasCapability(Status.IS_WEAPON_ITEM)){
                actor.addWeaponToInventory(purchaseItem);
            } else {
                actor.addItemToInventory(purchaseItem);
            }

            RuneManager.modifyRunes(-((Purchasable) purchaseItem).purchaseRuneValue());

            return actor + " bought " + purchaseItem + " from " + trader + " for " + ((Purchasable) purchaseItem).purchaseRuneValue();
        } else{
            return actor + " does not have enough runes to purchase " + purchaseItem + "!";
        }


    }

    /**
     * Describes which item the customer can buy for how much
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " buys " + purchaseItem + " from " + trader + " for " + ((Purchasable) purchaseItem).purchaseRuneValue();
    }
}
