package game.subactions;

import game.enemies.Hostile;
import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;

import edu.monash.fit2099.engine.positions.GameMap;

/**
 * An action that despawns an enemy from the game world.
 * Created by:
 * @author Timothy
 * Modified by:
 * @author Charlene
 */
public class DespawnAction extends Action {



    public DespawnAction() {

    }

    /**
     * Despawns the enemy from the game world.
     *
     * @param actor the actor performing the action (not used in this implementation)
     * @param map   the map the actor is on (not used in this implementation)
     * @return a description of the despawn action
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.removeActor(actor);
        return actor + " has been despawned from the game world.";
    }

    /**
     * Returns a description of the despawn action.
     *
     * @param actor the actor performing the action (not used in this implementation)
     * @return a description of the despawn action
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Despawn " + actor;
    }
}
