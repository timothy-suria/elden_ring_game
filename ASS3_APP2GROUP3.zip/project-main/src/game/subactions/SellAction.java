package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.RuneManager;
import game.interfaces.Sellable;
import game.traders.Trader;
/**
 * An Action to Sell an Item
 * Created by:
 * @author Argya
 * Modified by:
 *
 */
public class SellAction extends Action {
    /**
     * The Weapon to be sold to the Trader
     */
    private WeaponItem sellWeapon;
    /**
     * The Item to be sold to the Trader
     */
    private Item sellItem;
    /**
     * Boolean to check if the thing being sold is a Weapon
     */
    private boolean sellingWeapon = false;
    /**
     * The trader that is buying the sold item
     */
    private Trader trader;

    /**
     * Constructor.
     *
     * @param item The Weapon to be sold to the Trader
     * @param seller The trader that is buying the sold item
     */
    public SellAction(WeaponItem item, Trader seller) {
        sellingWeapon = true;
        sellWeapon = item;
        trader = seller;
    }
    /**
     * Constructor.
     *
     * @param item The Item to be sold to the Trader
     * @param seller The trader that is buying the sold item
     */
    public SellAction(Item item, Trader seller) {
        sellItem = item;
        trader = seller;
    }

    /**
     *  When executed, it checks if the thing being sold is a weapon or not. Then it removes
     *  it from the weapon inventory or the item inventory, and adds its sell value to the seller's rune count.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the result of the selling, showing which actor sold what to who for how much.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if(sellingWeapon){
            actor.removeWeaponFromInventory(sellWeapon);
            RuneManager.modifyRunes(((Sellable) sellWeapon).sellRuneValue());
            return actor + " sold " + sellWeapon + " to " + trader + " for " + ((Sellable) sellWeapon).sellRuneValue();
        } else {
            actor.removeItemFromInventory(sellItem);
            RuneManager.modifyRunes(((Sellable) sellItem).sellRuneValue());
            return actor + " sold " + sellItem + " to " + trader + " for " + ((Sellable) sellItem).sellRuneValue();
        }

    }

    /**
     * Describes what actor is selling what thing to who for how much.
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        if(sellingWeapon){
            return actor + " sells " + sellWeapon + " to " + trader + " for " + ((Sellable) sellWeapon).sellRuneValue();
        } else{
            return actor + " sells " + sellItem + " to " + trader + " for " + ((Sellable) sellItem).sellRuneValue();
        }

    }
}
