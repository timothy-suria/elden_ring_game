package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.environments.SiteOfLostGrace;

/**
 * A class representing the Action to activate/discover the Lost Grace.
 */
public class ActivateGraceAction extends Action {

    SiteOfLostGrace grace;

    /**
     * Constructor
     * @param grace the grace being activated
     */
    public ActivateGraceAction(SiteOfLostGrace grace){
        this.grace = grace;
    }

    /**
     * When executed, the grace becomes found
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the text describing what happens
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        grace.found();
        return actor +" activates the Site of Lost Grace.";
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor +" activates the Site of Lost Grace.";
    }
}
