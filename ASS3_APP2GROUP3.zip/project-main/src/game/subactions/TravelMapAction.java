package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;

/**
 * This class represents the action done to travel between maps using a Fog Door.
 * @author Argya
 */
public class TravelMapAction extends Action {

    /**
     * A description of the map to travel to
     */
    private String destinationMap;
    /**
     * The location to be sent to (on the other map)
     */
    private Location destinationLocation;

    /**
     * Constructor
     * @param dest description of the destination
     * @param loc the location of the destination
     */
    public TravelMapAction(String dest, Location loc){
        destinationMap = dest;
        destinationLocation = loc;
    }

    /**
     * Moves the inputted actor from their current GameMap to the target GameMap
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return description of the action
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.moveActor(actor, destinationLocation);
        return actor + " traverses the golden fog door and goes to " + destinationMap;
    }


    /**
     * Menu description of the action
     * @param actor The actor performing the action.
     * @return description of the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " traverses the golden fog door and goes to " + destinationMap;
    }
}
