package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.environments.SiteOfLostGrace;
import game.interfaces.Playable;
import game.Utils.ResetManager;


/**

 A ResetGameAction represents an action that resets the game map and player's respawn location.
 This action is intended to be executed by the player.
 @author timothy suria
 Modified by:
 @author Argya
 */
public class ResetGameAction extends Action {

    Actor user;
    Location resetLocation;
    SiteOfLostGrace grace;

    /**
     * Constructor for ResetGameAction.
     *
     * @param user the player who will trigger this action
     * @param resetLocation the location where the player will respawn after the game is reset
     */
    public ResetGameAction(Actor user, Location resetLocation, SiteOfLostGrace grace){
        this.user = user;
        this.resetLocation = resetLocation;
        this.grace = grace;
    }

    /**
     * Executes the reset game action by setting the player's respawn location to the reset location,
     * and then running the reset manager to reset the game map.
     *
     * @param actor the actor performing the action
     * @param map the game map
     * @return a string describing the action that was performed
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        ((Playable) user).setRespawnLocation(resetLocation);
        System.out.println("Reset Game Action triggered");
        ResetManager.getInstance().run(map);
        return menuDescription(actor);
    }

    /**
     * Returns a string describing the action that will be displayed in the menu.
     *
     * @param actor the actor performing the action
     * @return a string describing the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return "The game resets, " + actor + " is resting in Site of Lost Grace.";
        }
}