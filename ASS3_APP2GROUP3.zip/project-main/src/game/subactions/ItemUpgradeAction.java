package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.Utils.RuneManager;
import game.Utils.enums.Status;
import game.interfaces.Consumable;
import game.traders.Trader;

/**
 * Class ItemUpgradeAction. Upgrade an item if the material condition is met.
 * Created by:
 * @author Charlene
 */
public class ItemUpgradeAction extends Action {

    /**
     * The Item to be upgraded
     */
    private Item upgradeItem;

    /**
     * The trader that is upgrading item
     */
    private Trader trader;

    /**
     * Constructor.
     *
     * @param item The Item to be sold to the Trader
     * @param seller The trader that is buying the sold item
     */
    public ItemUpgradeAction(Item item, Trader seller) {
        upgradeItem = item;
        trader = seller;
    }

    /**
     *  When executed, it checks if the thing being upgrade can be upgraded
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the result of the upgrading attempt
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if(RuneManager.getRunes() > (6000)){ //Hardcoded atm. CHANGE
            if (upgradeItem.hasCapability(Status.IS_UPGRADABLE))
            {
                RuneManager.modifyRunes(-6000);
                ((Consumable) upgradeItem).increaseMaxUse();
                return actor + " bought an upgrade for " + upgradeItem + " from " + trader ;
            }
        }
        return actor + " does not have enough runes to purchase an upgrade";
    }

    /**
     * Describes what actor is upgrading and for how much.
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " upgrades " + upgradeItem + " for " + 6000;
    }
}
