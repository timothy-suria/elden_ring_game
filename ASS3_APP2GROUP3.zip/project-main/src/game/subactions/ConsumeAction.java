package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.interfaces.Consumable;

/**
 * An Action to consume a Consumable
 * Created by:
 * @author Argya
 * Modified by:
 *
 */
public class ConsumeAction extends Action {

    /**
     * The Actor that is consuming the Consumable
     */
    private Actor consumer;

    /**
     * The Consumable to be consumed
     */
    private Consumable usedItem;

    /**
     * Constructor.
     *
     * @param user The actor consuming the Consumable.
     * @param consumable The Consumable to be consumed.
     */
    public ConsumeAction(Actor user, Consumable consumable){
        this.consumer = user;
        this.usedItem = consumable;

    }

    /**
     * When executed, the consume() method is called from the Actor consuming. The user
     * is put into the method as an argument, so any effects that come from consuming occur
     * to the user.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return The result of consuming the Consumable.
     */
    @Override
    public String execute(Actor actor, GameMap map) {

        return usedItem.consume(consumer);

    }

    /**
     * Describes which actor consumed what item.
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " consume " + usedItem;
    }
}
