package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.Utils.FancyMessage;
import game.Utils.ResetManager;
import game.Utils.RuneManager;
import game.Utils.deathOnlyResetManager;
import game.Utils.enums.Status;
import game.interfaces.AlternateDeathCapable;
import game.interfaces.NPCDropRunesCapable;
import game.interfaces.Playable;
import game.subitems.DroppedRunes;

/**
 * An action executed if an actor is killed.
 * Created by:
 * @author Adrian Kristanto
 * Modified by: Argya, Charlene, Timothy
 *
 */
public class DeathAction extends Action {
    private Actor attacker;

    public DeathAction(Actor actor) {
        this.attacker = actor;
    }

    /**
     * When the target is killed, the items & weapons carried by target
     * will be dropped to the location in the game map where the target was
     *
     * @param target The actor performing the action.
     * @param map The map the actor is on.
     * @return result of the action to be displayed on the UI
     */
    @Override
    public String execute(Actor target, GameMap map) {
        String result = "";

        if(target.hasCapability(Status.PLAYER)){
            Playable player = ((Playable) target);
            Location previousDeath = player.getDeathLocation();
            deathOnlyResetManager.getInstance().run(map);
            if(previousDeath != null){
                Item toBeRemoved = null;
                for (Item item: previousDeath.getItems()){
                    if(item.hasCapability(Status.DROPPED_RUNES)){
                        toBeRemoved = item;
                    }
                }
                if(toBeRemoved != null){
                    previousDeath.removeItem(toBeRemoved);
                }
            }

            player.setDeathLocation(map.locationOf(target));
            result += menuDescription(target);
            ResetManager.getInstance().run(map);
            if(map.locationOf(target) != player.getRespawnLocation()){
                map.moveActor(target, player.getRespawnLocation());
            }
            //insert dropping runes here

            player.getLastLocation().addItem(new DroppedRunes(RuneManager.getRunes()));
            RuneManager.setRunes(0);
            return result;
        }

        if(!target.hasCapability(Status.ALTERNATE_DEATH)){
            ActionList dropActions = new ActionList();
            // drop all items
            for (Item item : target.getItemInventory())
                dropActions.add(item.getDropAction(target));
            for (WeaponItem weapon : target.getWeaponInventory())
                dropActions.add(weapon.getDropAction(target));
            for (Action drop : dropActions)
                drop.execute(target, map);
            // remove actor
            map.removeActor(target);
            result += System.lineSeparator() + menuDescription(target);

            if(attacker.hasCapability(Status.PLAYER)){
                RuneManager.modifyRunes(((NPCDropRunesCapable) target).getRunes());
                result += " " + target + " has dropped " + ((NPCDropRunesCapable) target).getRunes() + " runes.";
            }
        } else{
            ((AlternateDeathCapable) target).alternateDeath(map);
            return " "+((AlternateDeathCapable) target).alternateDescription(target);
        }


        return result;
    }


    @Override
    public String menuDescription(Actor actor) {
        if(!actor.isConscious() && actor.hasCapability(Status.PLAYER)) {
            for (String line : FancyMessage.YOU_DIED.split("\n")) {
                new Display().println(line);
                try {
                    Thread.sleep(200);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }
        return actor + " is killed.";
    }
}
