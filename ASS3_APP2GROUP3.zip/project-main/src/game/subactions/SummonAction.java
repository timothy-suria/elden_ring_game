package game.subactions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.allies.Ally;
import game.classes.*;
import game.enemies.Invader;

import static game.Utils.RandomNumberGenerator.getRandomInt;

/**
 * Class SummonAction
 * Summons either an invader or an ally
 * Created by:
 * @author Charlene
 */

public class SummonAction extends Action {
    /**
     *  Actor user:
     *  Player
     */
    Actor user;
    /**
     * Location summonLocation:
     * Location of summon sign and spawn point for the summon
     */
    Location summonLocation;

    /**
     * Constructor SummonAction:
     * Initialize variables
     * @param user
     * Player
     * @param summonLocation
     * Location of summon sign and spawn location for summon
     */
    public SummonAction(Actor user, Location summonLocation){
        this.user = user;
        this.summonLocation = summonLocation;
    }

    /**
     * Method execute:
     * Executes action. Summon a random invader or ally
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return
     * String of what has happened
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        System.out.print("You have summoned a ");
        int chance=getRandomInt(4);
        PlayerClass summonClass = switch (chance) {
            case 0 -> new Wretch();
            case 1 -> new Bandit();
            case 2 -> new Samurai();
            case 3 -> new Astrologer();
            default -> new Wretch();
        };
        if (getRandomInt(2)<1)
        {
            summonLocation.addActor(new Invader(summonClass));
            return "enemy " + summonClass.getClassName();
        }
        else {
            summonLocation.addActor(new Ally(summonClass));
            return "ally "+ summonClass.getClassName();
        }
    }

    /**
     * Method menuDescription
     * @param actor The actor performing the action.
     * @return String
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " uses the summon sign ";
    }
}
