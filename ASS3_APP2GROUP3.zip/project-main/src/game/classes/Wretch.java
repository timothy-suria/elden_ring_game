package game.classes;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.subweapon.Club;

/**
 * Wretch, extends from PlayerClass abstract class. Is one possible player class
 * Default weapon is a Club
 * Created by:
 * @author Charlene
 */
public class Wretch extends PlayerClass{

    /**
     * int startingHealth represents starting health of the class
     */
    private int startingHealth=414;

    /**
     * String className represents String version of the class name
     */
    private String className="Wretch";

    /**
     * WeaponItem weapon represents starting weapon of the class. Samurai starts with an uchigatana
     */
    private WeaponItem weapon= new Club();
    public int getStartingHealth() {
        return startingHealth;
    }

    /**
     * Method getClassName to return name of the class
     * @return className, string of the name
     */
    public String getClassName() {
        return className;
    }

    /**
     * Method getWeapon to get weapon assigned
     * @return WeaponItem, default weapon of class which is uchigatana
     */
    public WeaponItem getWeapon() {
        return weapon;
    }
}
