package game.classes;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import game.classes.Bandit;
import game.classes.PlayerClass;
import game.classes.Samurai;
import game.classes.Wretch;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

/**
 * A menu GUI implementations for Class selection
 *
 * @author Charlene
 */
public class ClassMenu {

    /**
     * Display a menu to the user and have them select an option.
     *
     * @return the PlayerClass selected by the user
     */
    public PlayerClass showMenu() {
        Display display=new Display();
        display.println("""
                Please select your background.\s
                 1) Samurai, you are a trained warrior carrying an Uchigatana.\s
                 2) You are a fleet-footed bandit carrying a great knife\s
                 3) You are an Astrologer. A scholar who reads fate in the stars. \s
                 4) You are a miserable wretch with nothing but a decrepit club""");

        Character choice=display.readChar();
        while (!(choice.equals('1')||choice.equals('2')||choice.equals('3')||choice.equals('4')))
        {
            display.println("Pick 1,2,3 or 4");
            choice=display.readChar();
        }
        return switch (choice) {
            case '1' -> new Samurai();
            case '2' -> new Bandit();
            case '3' -> new Astrologer();
            case '4' -> new Wretch();
            default -> new Wretch();
        };


    }
}
