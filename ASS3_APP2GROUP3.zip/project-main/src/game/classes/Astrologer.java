package game.classes;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.subweapon.Club;

/**
 * class Astrologer
 * Player class Astrologer
 *
 * Created by:
 * @author charlene
 */
public class Astrologer extends PlayerClass{
    /**
     * int startingHealth represents starting health of the class
     */
    private int startingHealth=396;

    /**
     * String className represents String version of the class name
     */
    private String className="Astrologer";

    /**
     * WeaponItem weapon represents starting weapon of the class. Should be a Staff but that is an optional requirement
     */
    private WeaponItem weapon= new Club();
    public int getStartingHealth() {
        return startingHealth;
    }

    /**
     * Method getClassName to return name of the class
     * @return className, string of the name
     */
    public String getClassName() {
        return className;
    }

    /**
     * Method getWeapon to get weapon assigned
     * @return WeaponItem
     */
    public WeaponItem getWeapon() {
        return weapon;
    }
}
