package game.classes;

import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.subweapon.GreatKnife;
/**
 * Bandit, extends from PlayerClass abstract class. Is one possible player class
 * Default weapon is a Great Knife
 * Created by:
 * @author Charlene
 */
public class Bandit extends PlayerClass{

    /**
     * int startingHealth represents starting health of the class
     */
    private int startingHealth=414;

    /**
     * String className represents String version of the class name
     */
    private String className="Bandit";


    /**
     * WeaponItem weapon represents starting weapon of the class
     */
    private WeaponItem weapon=new GreatKnife();
    public int getStartingHealth() {
        return startingHealth;
    }

    /**
     * Method getClassName to return name of the class
     * @return className, string of the name
     */
    public String getClassName() {
        return className;
    }

    /**
     * Method getWeapon to get weapon assigned
     * @return WeaponItem, default weapon of class which is a great knife
     */
    public WeaponItem getWeapon() {
        return weapon;
    }

}
