package game.classes;

import edu.monash.fit2099.engine.weapons.WeaponItem;
/**
 * PlayerClass abstract class
 * Created by:
 * @author Charlene
 */
public abstract class PlayerClass {

    /**
     * int startingHealth represents starting health of the class
     */
    private int startingHealth;

    /**
     * String className represents String version of the class name
     */
    private String className;

    /**
     * WeaponItem weapon represents starting weapon of the class
     */
    private WeaponItem weapon;

    /**
     * Method getStartingHealth to get starting health
     * @return startingHealth, int
     */
    public int getStartingHealth() {
        return startingHealth;
    }

    /**
     * Method getClassName to return name of the class
     * @return className, string of the name
     */
    public String getClassName() {
        return className;
    }

    /**
     * Method getWeapon to get weapon assigned
     * @return WeaponItem, default weapon of class
     */
    public WeaponItem getWeapon() {
        return weapon;
    }
}
