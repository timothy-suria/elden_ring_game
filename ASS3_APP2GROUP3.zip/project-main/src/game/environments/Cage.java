package game.environments;

import game.enemies.EnemyManager;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.enums.CardinalDirection;

/**
 A class that represents a Cage terrain in the game.
 @author timothy suria
 */
public class Cage extends Ground {

    /**
     * double spawnChance represents 37% of the time the enemy will spawn
     */
    private static double spawnChance = 0.37;

    /**
     * char DISPLAY_CHAR represents visual character on the map
     */
    private static final char DISPLAY_CHAR = '<';

    /**
     * String cardinalDirection as a ground descriptor
     */
    private String cardinalDirection="West";

    /**
     * Constructor for the Cage terrain.
     * It creates a new Cage terrain with the display character '<',
     */
    public Cage() {
        super(DISPLAY_CHAR);
    }

    /**
     Spawns an enemy randomly with a certain probability.
     @param location the location to spawn the enemy at
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        EnemyManager.spawnEnemy(location,spawnChance,cardinalDirection);
    }

    /**
     Determines if an actor can enter this ground.
     @param actor the actor that is trying to enter the ground
     @return true, since any actor can enter the gust of wind
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return true;
    }
}
