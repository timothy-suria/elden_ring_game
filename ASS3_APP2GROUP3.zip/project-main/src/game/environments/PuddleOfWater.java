package game.environments;

import game.enemies.EnemyManager;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.enums.CardinalDirection;

/**
 A class that represents a PuddleOfWater terrain in the game.
 @author timothy suria
 */
public class PuddleOfWater extends Ground {

    /**
     * double spawnChance represents 2% of the time the enemy will spawn
     */
    private static double spawnChance = 0.02;

    /**
     * char DISPLAY_CHAR represents visual character on the map
     */
    private static final char DISPLAY_CHAR = '~';

    /**
     * String cardinalDirection as a ground descriptor
     */
    private String cardinalDirection="West";

    /**
     *constructor
     */
    public PuddleOfWater() {
        super(DISPLAY_CHAR);
        addCapability(CardinalDirection.WEST);
    }

    /**
     Spawns an enemy randomly with a certain probability.
     @param location the location to spawn the enemy at
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        EnemyManager.spawnEnemy(location,spawnChance,cardinalDirection);
    }

    /**
     Determines if an actor can enter this ground.
     @param actor the actor that is trying to enter the ground
     @return true, since any actor can enter the puddle of water
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return true;
    }
}
