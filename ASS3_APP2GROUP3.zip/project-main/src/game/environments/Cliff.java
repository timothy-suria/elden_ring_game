package game.environments;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.enums.Status;
import game.subactions.DeathAction;


/**
 A class that represents a Gust of wind terrain in the game.
 @author timothy suria
 */
public class Cliff extends Ground {

    public Cliff() {
        super('+');
        this.addCapability(Status.FATAL);
    }
    @Override
    public boolean canActorEnter(Actor actor) {
        if(actor.hasCapability(Status.PLAYER)){
        return true;
        }
        return false;
    }
    @Override
    public void tick(Location location) {
        if (location.containsAnActor()){
            Actor player = location.getActor();
            if (player.hasCapability(Status.PLAYER)){
                System.out.println(player + " stupidly falls off a cliff!");
            }
    }
}


}
