package game.environments;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.FancyMessage;
import game.Utils.enums.Status;
import game.subactions.ActivateGraceAction;
import game.subactions.ResetGameAction;

/**

 A class representing a special ground that can be interacted with to reset the game.

 @author Timothy Suria
 */
public class SiteOfLostGrace extends Ground {

    private String name;
    private boolean isFound = false;

    /**
     * Constructor.
     */
    public SiteOfLostGrace(){
        super('U');
    }


    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction){
        if (actor.hasCapability(Status.PLAYER)) {
            if(isFound){
                return new ActionList(new ResetGameAction(actor, location, this));
            } else{
                return new ActionList(new ActivateGraceAction(this));
            }

        }
        return new ActionList();
    }

    public void found(){
        if(!isFound){
            isFound = true;
            for (String line : FancyMessage.LOST_GRACE_FOUND.split("\n")) {
                new Display().println(line);
                try {
                    Thread.sleep(200);
                } catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }
    }

    public void setName(String graceName){
        name = graceName;
    }

    public String getName(){
        return name;
    }



}
