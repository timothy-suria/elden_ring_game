package game.environments;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.enums.Status;
import game.subactions.SummonAction;

/**
 * Class SummonSign
 * Ground Summon sign which allows player to summon beings from
 *
 * Created by:
 * @author charlene
 */
public class SummonSign extends Ground {
    /**
     * Constructor.
     *
     */
    public SummonSign() {
        super('=');
    }

    /**
     * method allowableActions
     * Actions allowed to be used here. Player can summon stuff from it
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return ActionList()
     */

    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction){
        if (actor.hasCapability(Status.PLAYER)) {
            return new ActionList(new SummonAction(actor, location));
        }
        return new ActionList();
    }
}
