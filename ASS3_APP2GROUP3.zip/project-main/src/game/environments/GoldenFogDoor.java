package game.environments;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.Utils.enums.Status;
import game.subactions.ResetGameAction;
import game.subactions.TravelMapAction;

public class GoldenFogDoor extends Ground {

    private Location destinationLocation;
    private String destinationString;

    /**
     * Constructor.
     */
    public GoldenFogDoor(Location loc, String dest) {
        super('D');
        destinationLocation = loc;
        destinationString = dest;
    }

    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction){
        if (actor.hasCapability(Status.PLAYER)) {
            return new ActionList(new TravelMapAction(destinationString, destinationLocation));
        }
        return new ActionList();
    }

}
