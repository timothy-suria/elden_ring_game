package game.environments;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.NumberRange;
import game.Utils.enums.CardinalDirection;
import game.environments.*;
/**
 * EastGroundFactory. Used to check and set if an environment should be east
 * Created by:
 * @author Charlene
 */
public class EastGroundFactory {

    /**
     * Constructor EastGroundFactory. Call to edit gamemap so there is an east and west.
     * @param gameMap
     * map of the zone
     */
    public EastGroundFactory(GameMap gameMap){

        NumberRange xrange=gameMap.getXRange();
        NumberRange yrange=gameMap.getYRange();
        int maxxrange=xrange.max();
        int halfmaxxrange=maxxrange/2;
        Ground tempGround;

        for (int y : yrange) {

            for (int x : xrange) {
                if (x==halfmaxxrange)
                    break;
                tempGround= gameMap.at(maxxrange-x,y).getGround();
                if (tempGround.hasCapability(CardinalDirection.WEST))
                {
                    if (Graveyard.class.equals(tempGround.getClass())) {
                        tempGround = new GraveyardEast();

                    } else if (GustOfWind.class.equals(tempGround.getClass())) {
                        tempGround = new GustOfWindEast();

                    } else if (PuddleOfWater.class.equals(tempGround.getClass())) {
                        tempGround = new PuddleOfWaterEast();
                    }
                }
                gameMap.at(maxxrange-x,y).setGround(tempGround);
            }
        }
    }

}
