package game.environments;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.enemies.EnemyManager;
import game.Utils.enums.CardinalDirection;


public class PuddleOfWaterEast extends Ground {

    /**
     * double spawnChance represents 1% of the time the enemy will spawn
     */
    private static double spawnChance = 0.01;

    /**
     * char DISPLAY_CHAR represents visual character on the map
     */
    private static final char DISPLAY_CHAR = '~';

    /**
     * String cardinalDirection as a ground descriptor
     */
    private String cardinalDirection="East";

    /**
     * Constructor for the puddle of water terrain.
     * It creates a new puddle of water east terrain with the display character '~',
     */
    public PuddleOfWaterEast() {
        super(DISPLAY_CHAR);
        addCapability(CardinalDirection.EAST);
    }

    /**
     Spawns an enemy randomly with a certain probability.
     @param location the location to spawn the enemy at
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        EnemyManager.spawnEnemy(location,spawnChance,cardinalDirection);
    }

    /**
     Determines if an actor can enter this ground.
     @param actor the actor that is trying to enter the ground
     @return true, since any actor can enter the puddle of water
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return true;
    }
}
