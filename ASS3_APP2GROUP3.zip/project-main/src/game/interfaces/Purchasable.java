package game.interfaces;

import game.Utils.enums.Status;

/**
 * A Purchasable interface
 *
 */
public interface Purchasable {
    /**
     * Gets the rune value of an item when purchased by a customer
     * @return the int value of the rune value
     */
    int purchaseRuneValue();

    abstract boolean hasCapability(Status isWeaponItem);

}
