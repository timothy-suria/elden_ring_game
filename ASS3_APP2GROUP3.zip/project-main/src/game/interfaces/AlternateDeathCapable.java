package game.interfaces;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * An AlternateDeathCapable interface. Used for classes that do something
 * else when they die.
 */
public interface AlternateDeathCapable {
    /**
     * A boolean to check if they die normally or not.
     */
    boolean dieNormally = false;

    /**
     * A method to be called during the Death Action
     * @param map the map the actor dying is on
     */
    void alternateDeath(GameMap map);

    /**
     * A description for what happens during the alternate death.
     * @param actor the actor dying
     * @return a description of what happens
     */
    String alternateDescription(Actor actor);

}

