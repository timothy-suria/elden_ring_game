package game.interfaces;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * A Consumable interface
 */
public interface Consumable {
    /**
     * Consume the consumable
     * @param user The Actor that consumes the Consumable
     * @return A string describing what happens
     */
    public String consume(Actor user);

    /**
     * Returns whether the consumable can still be used
     * @return whether the consumable can still be used
     */
    public boolean hasUses();

    /**
     * Sets the max use up by int
     */
    public void increaseMaxUse();

}
