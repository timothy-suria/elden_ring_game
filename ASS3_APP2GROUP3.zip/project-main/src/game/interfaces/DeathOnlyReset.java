package game.interfaces;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * A DeathOnlyReset interface
 * Created by:
 * @author Charlene
 *
 */

public interface DeathOnlyReset {
    void deathOnlyReset(GameMap map);
}
