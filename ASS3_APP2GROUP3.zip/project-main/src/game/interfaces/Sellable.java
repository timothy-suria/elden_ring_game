package game.interfaces;

import game.Utils.enums.Status;

/**
 * A Sellable interface
 *
 */
public interface Sellable {
    /**
     * Gets the rune value of an item when sold to a Trader
     * @return rune value when sold to a Trader
     */
    int sellRuneValue();

    /**
     * Checks if something is a WeaponItem
     * @param isWeaponItem an ENUM Status
     * @return if something is a WeaponItem
     */
    abstract boolean hasCapability(Status isWeaponItem);

}
