package game.interfaces;

/**
 * An NPCDropRunesCapable interface.
 */
public interface NPCDropRunesCapable {
    /**
     * The number of runes the NPC has.
     */
    int runes = 0;

    /**
     * Get the number of runes the NPC has.
     * @return the number of runes
     */
    int getRunes();

    /**
     * Set the number of runes the NPC has.
     * @param runes the number of runes to set
     */
    void setRunes(int runes);
}
