package game.interfaces;

import edu.monash.fit2099.engine.positions.GameMap;

import java.util.List;

/**
 * A MapArea interface
 * created by:
 * @author Argya
 */
public interface MapArea {

    /**
     * Returns the MapArea's GameMap
     * @return a GameMap representing the MapArea
     */
    public GameMap getGameMap();


}
