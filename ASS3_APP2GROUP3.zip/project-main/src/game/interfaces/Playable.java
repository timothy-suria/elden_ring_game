package game.interfaces;

import edu.monash.fit2099.engine.positions.Location;

/**
 * A Playable interface
 */
public interface Playable {
    /**
     * Sets the last location the Player was at
     * @param location the last location the Player was at
     */
    void setLastLocation(Location location);

    /**
     * Returns the last location the Player was at
     * @return the last location the Player was at
     */
    Location getLastLocation();

    /**
     * Sets the location the Player died at
     * @param location the location the Player died at
     */
    void setDeathLocation(Location location);

    /**
     * Returns the location the Player died at
     * @return the location the Player died at
     */
    Location getDeathLocation();

    /**
     * Sets the location the Player should spawn at
     * @param location the location the Player should spawn at
     */
    void setRespawnLocation(Location location);

    /**
     * Gets the location the Player should spawn at
     * @return the location the Player should spawn at
     */
    Location getRespawnLocation();

}
