package game.interfaces;


import edu.monash.fit2099.engine.positions.GameMap;

/**
 * A resettable interface
 * Created by:
 * @author Adrian Kristanto
 * Modified by:Timothy Suria
 *
 */

public interface Resettable {
    void reset(GameMap map);
}
