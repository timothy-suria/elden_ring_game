# FIT2099 Assignment (Semester 1, 2023)
# Elden Ring

## XX_LabYYTeamZZ
Team members:

## Design Rationale

## Contribution Log
https://docs.google.com/spreadsheets/u/3/d/1XPvAJ9Vtio5G_PRjIPaz2qi_vDXUIuphGTyR7M56P7g/edit#gid=0
